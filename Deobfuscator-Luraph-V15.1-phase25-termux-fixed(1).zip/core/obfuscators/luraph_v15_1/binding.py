"""Bind the V15.1 AST mapper into the proven V15 lifter, without modifying V15.

The V15 lifter keeps its implementation in ``obfuscators.luraph_v15.devirt``.
Its functions resolve the module-global ``vmmap`` at runtime, so a V15.1 job can
swap only that dependency for the lifetime of the job.  The original mapper and
source-cache are restored afterwards, which keeps mixed-profile test processes
safe.
"""
from __future__ import annotations

from contextlib import contextmanager
from typing import Iterator

from obfuscators.luraph_v15 import devirt as base_devirt
from . import vmmap as v151_vmmap


@contextmanager
def bound_v151() -> Iterator[object]:
    old_vmmap = base_devirt.vmmap
    old_cache = getattr(base_devirt, "_SOURCE_CACHE", None)
    base_devirt.vmmap = v151_vmmap
    if old_cache is not None:
        # Source analysis results are mapper-dependent. Do not reuse a V15 AST
        # analysis under the V15.1 mapper or vice versa.
        base_devirt._SOURCE_CACHE = {}
    try:
        yield base_devirt
    finally:
        base_devirt.vmmap = old_vmmap
        if old_cache is not None:
            base_devirt._SOURCE_CACHE = old_cache


def activate_v151() -> object:
    """Activate V15.1 mapping for a short-lived bridge process.

    The bridge process handles one profile and then exits, so leaving the
    binding active is safe there.  Library callers should prefer ``bound_v151``
    for exception-safe restoration.
    """
    base_devirt.vmmap = v151_vmmap
    if hasattr(base_devirt, "_SOURCE_CACHE"):
        base_devirt._SOURCE_CACHE = {}
    return base_devirt
