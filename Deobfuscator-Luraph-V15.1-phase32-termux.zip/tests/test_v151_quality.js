'use strict';
const assert = require('assert');
const q = require('../src/v151_quality');

const probe = [
  'Instance.new(\"Folder\")',
  'local ScreenGui = Instance.new(\"ScreenGui\")',
  'local Frame = Instance.new(\"Frame\")',
  'local Path2D = Instance.new(\"Path2D\")',
  'Frame.Parent = ScreenGui',
  'Path2D.Parent = Frame',
].join('\n');
assert(q.isSuspiciousLift(probe, 1096227), 'the 6-line probe output must be rejected');
assert.strictEqual(q.scoreLift(probe, 1096227).probeObjects, 4);

const large = 'local x = 1\n'.repeat(1000);
assert(!q.isSuspiciousLift(large, 1096227), 'large non-probe output must not be rejected');

const data = {protos: {
  a:{__maker:'vm-a',__seq:1},
  b:{__maker:'vm-a',__seq:2},
  c:{__maker:'vm-a',__seq:3},
  d:{__maker:'vm-b',__seq:4},
}};
assert.deepStrictEqual(q.structuralRootCandidates(data), ['a','d']);


// Phase 32: stale root_callee hints must not outrank a rich payload proto.
{
  const data = {
    root_callee: 1,
    root_probes: [1],
    protos: {
      1: { __maker: 10, body: 'P'.repeat(200) },
      2: { __maker: 20, body: 'P'.repeat(50000) },
    },
  };
  const ranked = q.rootCandidateRanking(data);
  assert.strictEqual(ranked[0].pid, 2);
}

// Phase 32: the canonical six-line V15.1 probe is always suspicious.
{
  const probe = [
    'Instance.new("Folder")',
    'local ScreenGui = Instance.new("ScreenGui")',
    'local Frame = Instance.new("Frame")',
    'local Path2D = Instance.new("Path2D")',
    'Frame.Parent = ScreenGui',
    'Path2D.Parent = Frame',
  ].join('\n');
  assert.strictEqual(q.probeFingerprint(probe).exact, true);
  assert.strictEqual(q.isSuspiciousLift(probe, 100), true);
}
console.log('v151 quality gate: PASS');
const ranked = q.rootCandidateRanking({
  root_ok: [30],
  root_candidates: [20],
  root_callee: 20,
  root_probes: [20],
  protos: {10:{__maker:'vm-a',__seq:1},20:{__maker:'vm-a',__seq:2},30:{__maker:'vm-b',__seq:3}}
});
assert.strictEqual(ranked[0].pid, 30, 'runtime root-ok must rank first');
assert(q.isWeakLift(probe, 1096227), 'probe output must be weak/suspicious');
assert.strictEqual(q.compareLift('local a=1\n', probe, 1096227), 1);

const richRank = q.rootCandidateRanking({
  root_probes: [10],
  protos: {
    10:{__maker:'vm-a',__seq:1,x:1},
    20:{__maker:'vm-a',__seq:2,payload:'X'.repeat(20000)}
  }
});
assert.strictEqual(richRank[0].pid, 20, 'a large non-probe proto should surface as a recovery candidate');
assert(richRank[0].reasons.includes('proto-richness'));
