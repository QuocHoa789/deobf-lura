"""Deterministic V15.1 root/proto candidate ranking.

Runtime telemetry is evidence, not a license to override every root blindly.
The ranker keeps the original V15 fallback available when V15.1 evidence is
missing or contradictory.
"""
from __future__ import annotations

from typing import Any, Dict, Iterable, List, Mapping


def _ints(values: Iterable[Any]) -> List[int]:
    out: List[int] = []
    for value in values or ():
        try:
            n = int(value)
        except (TypeError, ValueError):
            continue
        if n not in out:
            out.append(n)
    return out


def _proto_richness(cap: Mapping[str, Any] | None) -> float:
    """Approximate captured proto richness without walking nested state."""
    if not isinstance(cap, Mapping):
        return 0.0
    try:
        import json
        n = len(json.dumps(cap, ensure_ascii=False, separators=(",", ":")))
    except Exception:
        return 0.0
    if n <= 0:
        return 0.0
    score = (__import__('math').log10(n + 1) * 25.0) - 25.0
    return max(0.0, min(120.0, score))


def rank_root_candidates(raw: Mapping[str, Any] | None,
                         protos: Mapping[str, Any] | None) -> List[Dict[str, Any]]:
    raw = raw or {}
    protos = protos or {}
    root_ok = _ints(raw.get("root_ok"))
    root_probe = set(_ints(raw.get("root_probes")))
    generic = _ints(raw.get("root_candidates"))
    root_callee = _ints([raw.get("root_callee")])

    # Structural maker information is a fallback only. Do not make a probe
    # competitive with positive runtime evidence.
    maker_counts: Dict[str, int] = {}
    first_seq: Dict[str, int] = {}
    for pid, cap in protos.items():
        if not isinstance(cap, Mapping) or cap.get("__maker") is None:
            continue
        maker = str(cap.get("__maker"))
        try:
            seq = int(cap.get("__seq") or 0)
        except (TypeError, ValueError):
            seq = 0
        maker_counts[maker] = maker_counts.get(maker, 0) + 1
        if maker not in first_seq or (seq and seq < first_seq[maker]):
            first_seq[maker] = seq

    structural: List[int] = []
    richness = []
    for pid, cap in protos.items():
        if not isinstance(cap, Mapping) or cap.get("__maker") is None:
            continue
        try:
            richness.append((int(pid), _proto_richness(cap)))
        except (TypeError, ValueError):
            continue
    richness.sort(key=lambda x: (-x[1], x[0]))
    richness = richness[:24]

    makers = sorted(maker_counts, key=lambda m: (-maker_counts[m], first_seq.get(m, 0), m))
    for maker in makers:
        rows = []
        for pid, cap in protos.items():
            if isinstance(cap, Mapping) and str(cap.get("__maker")) == maker:
                try:
                    seq = int(cap.get("__seq") or 0)
                except (TypeError, ValueError):
                    seq = 0
                rows.append((seq, str(pid)))
        if rows:
            rows.sort(key=lambda x: (x[0] == 0, x[0], x[1]))
            try:
                structural.append(int(rows[0][1]))
            except ValueError:
                pass

    scores: Dict[int, float] = {}
    reasons: Dict[int, List[str]] = {}
    order: Dict[int, int] = {}

    def touch(pid: int, score: float, reason: str, pos: int = 10_000) -> None:
        if str(pid) not in protos:
            return
        scores[pid] = scores.get(pid, 0.0) + score
        reasons.setdefault(pid, []).append(reason)
        order[pid] = min(order.get(pid, pos), pos)

    for pos, pid in enumerate(root_ok):
        touch(pid, 300.0 - pos * 3.0, "runtime-root-ok", pos)
    for pos, pid in enumerate(generic):
        touch(pid, 140.0 - min(pos, 20) * 2.0, "runtime-candidate", 50 + pos)
    for pos, pid in enumerate(root_callee):
        touch(pid, 100.0 - pos * 2.0, "runtime-root-callee", pos)
    for pos, pid in enumerate(structural):
        touch(pid, 8.0 - min(pos, 8), "structural-candidate", 200 + pos)
    for pos, (pid, rich) in enumerate(richness):
        touch(pid, rich, "proto-richness", 300 + pos)

    for pid in root_probe:
        if pid in scores:
            scores[pid] -= 80.0
            reasons.setdefault(pid, []).append("runtime-probe-penalty")
        elif str(pid) in protos:
            touch(pid, -20.0, "runtime-probe-only", 500)

    ranked = sorted(scores, key=lambda pid: (-scores[pid], order.get(pid, 10_000), pid))
    return [
        {"pid": pid, "score": scores[pid], "reasons": reasons.get(pid, [])}
        for pid in ranked
    ]


def ranked_ids(raw: Mapping[str, Any] | None, protos: Mapping[str, Any] | None,
               limit: int = 16) -> List[int]:
    return [int(row["pid"]) for row in rank_root_candidates(raw, protos)[:max(0, limit)]]
