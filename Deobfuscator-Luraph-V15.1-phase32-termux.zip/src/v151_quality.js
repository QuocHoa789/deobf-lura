'use strict';

function structuralRootCandidates(data) {
  const groups = new Map();
  for (const [pid, cap] of Object.entries((data && data.protos) || {})) {
    if (!cap || cap.__maker == null) continue;
    const maker = String(cap.__maker);
    const seq = Number(cap.__seq) || 0;
    let g = groups.get(maker);
    if (!g) {
      g = { maker, count: 0, firstPid: pid, firstSeq: seq };
      groups.set(maker, g);
    }
    g.count += 1;
    if (seq && (!g.firstSeq || seq < g.firstSeq)) {
      g.firstSeq = seq;
      g.firstPid = pid;
    }
  }
  return [...groups.values()]
    .sort((a, b) => (b.count - a.count) || (a.firstSeq - b.firstSeq) || a.maker.localeCompare(b.maker))
    .map(x => x.firstPid);
}

function protoRichness(cap) {
  // A real payload proto usually carries materially more captured state than
  // the tiny GUI/fingerprint helpers that caused the Phase 26 false-success.
  // JSON size is used only as a ranking hint; runtime root evidence still wins.
  try {
    const n = JSON.stringify(cap || {}).length;
    if (!Number.isFinite(n) || n <= 0) return 0;
    const score = Math.log10(n + 1) * 25 - 25;
    return Math.max(0, Math.min(120, score));
  } catch (_) {
    return 0;
  }
}

function rootCandidateRanking(data) {
  const protos = (data && data.protos) || {};
  const rootOk = Array.isArray(data && data.root_ok) ? data.root_ok : [];
  const rootProbe = new Set(Array.isArray(data && data.root_probes) ? data.root_probes.map(Number) : []);
  const generic = Array.isArray(data && data.root_candidates) ? data.root_candidates : [];
  const rootCallee = data && data.root_callee != null ? [data.root_callee] : [];
  const structural = structuralRootCandidates(data || {});
  const richness = Object.entries(protos)
    .filter(([, cap]) => cap && cap.__maker != null)
    .map(([pid, cap]) => ({ pid: Number(pid), richness: protoRichness(cap) }))
    .filter(x => Number.isFinite(x.pid))
    .sort((a, b) => (b.richness - a.richness) || (a.pid - b.pid))
    .slice(0, 24);
  const scores = new Map();
  const reasons = new Map();
  const order = new Map();

  const add = (x, score, reason, pos) => {
    const pid = Number(x);
    if (!Number.isFinite(pid) || !Object.prototype.hasOwnProperty.call(protos, String(pid))) return;
    scores.set(pid, (scores.get(pid) || 0) + score);
    const arr = reasons.get(pid) || [];
    arr.push(reason);
    reasons.set(pid, arr);
    order.set(pid, Math.min(order.has(pid) ? order.get(pid) : 10000, pos));
  };

  rootOk.forEach((x, i) => add(x, 300 - i * 3, 'runtime-root-ok', i));
  generic.forEach((x, i) => add(x, 140 - Math.min(i, 20) * 2, 'runtime-candidate', 50 + i));
  // root_callee is a hint written by the bridge, not positive runtime proof.
  // Keep it useful for compatibility, but let a rich payload proto outrank a
  // stale/helper hint unless runtime root_ok explicitly confirmed it.
  rootCallee.forEach((x, i) => add(x, 28 - i * 2, 'runtime-root-callee-hint', i));
  structural.forEach((x, i) => add(x, 8 - Math.min(i, 8), 'structural-candidate', 200 + i));
  richness.forEach((x, i) => {
    // Keep richness below a positively observed runtime root, but high enough
    // to surface a large payload proto when the observed root is a probe/helper.
    add(x.pid, x.richness, 'proto-richness', 300 + i);
  });
  for (const x of rootProbe) {
    const pid = Number(x);
    if (!Number.isFinite(pid) || !Object.prototype.hasOwnProperty.call(protos, String(pid))) continue;
    if (scores.has(pid)) {
      scores.set(pid, scores.get(pid) - 80);
      reasons.get(pid).push('runtime-probe-penalty');
    } else {
      add(pid, -20, 'runtime-probe-only', 500);
    }
  }

  return [...scores.keys()]
    .sort((a, b) => (scores.get(b) - scores.get(a)) ||
      ((order.get(a) || 10000) - (order.get(b) || 10000)) || (a - b))
    .map(pid => ({ pid, score: scores.get(pid), reasons: reasons.get(pid) || [] }));
}

function probeFingerprint(text) {
  const t = String(text || '').replace(/\r/g, '').trim();
  if (!t) return { exact: false, probeObjects: 0, guiParents: 0, lines: 0 };
  const rows = t.split('\n').map(x => x.trim()).filter(Boolean);
  const probeObjects = (t.match(/Instance\.new\("(?:Folder|ScreenGui|Frame|Path2D|ImageButton|TextLabel)"/g) || []).length;
  const guiParents = (t.match(/\b(?:Parent|Adornee)\s*=\s*\w+/g) || []).length;
  const exact = rows.length === 6 &&
    rows[0] === 'Instance.new("Folder")' &&
    rows[1] === 'local ScreenGui = Instance.new("ScreenGui")' &&
    rows[2] === 'local Frame = Instance.new("Frame")' &&
    rows[3] === 'local Path2D = Instance.new("Path2D")' &&
    rows[4] === 'Frame.Parent = ScreenGui' &&
    rows[5] === 'Path2D.Parent = Frame';
  return { exact, probeObjects, guiParents, lines: rows.length };
}

function isSuspiciousLift(text, sourceSize) {
  const fp = probeFingerprint(text);
  if (fp.exact) return true;
  if (sourceSize < 100000 || fp.lines > 80) return false;
  return fp.lines <= 16 && fp.probeObjects >= 2 && fp.guiParents >= 1;
}

function scoreLift(text, sourceSize) {
  const t = String(text || '');
  const lines = t.split(/\r?\n/).filter(x => x.trim() !== '').length;
  const probeObjects = (t.match(/Instance\.new\("(?:Folder|ScreenGui|Frame|Path2D|ImageButton|TextLabel)"/g) || []).length;
  const guiParents = (t.match(/\bParent\s*=\s*\w+/g) || []).length;
  const comments = (t.match(/^\s*--/gm) || []).length;
  const codeLines = Math.max(0, lines - comments);
  const weak = sourceSize >= 100000 && codeLines <= 12;
  return {
    lines,
    sourceSize,
    probeObjects,
    guiParents,
    comments,
    codeLines,
    weak,
    suspicious: isSuspiciousLift(t, sourceSize),
  };
}

function isWeakLift(text, sourceSize) {
  const q = scoreLift(text, sourceSize);
  return q.suspicious || q.weak;
}

function compareLift(aText, bText, sourceSize) {
  const a = scoreLift(aText, sourceSize);
  const b = scoreLift(bText, sourceSize);
  const aBad = (a.suspicious ? 100000 : 0) + (a.weak ? 10000 : 0);
  const bBad = (b.suspicious ? 100000 : 0) + (b.weak ? 10000 : 0);
  if (aBad !== bBad) return aBad < bBad ? 1 : -1;
  const aValue = a.codeLines + Math.min(50, a.lines) * 0.1 + Math.min(10, a.probeObjects) * -1;
  const bValue = b.codeLines + Math.min(50, b.lines) * 0.1 + Math.min(10, b.probeObjects) * -1;
  return aValue === bValue ? 0 : (aValue > bValue ? 1 : -1);
}

module.exports = {
  structuralRootCandidates,
  rootCandidateRanking,
  isSuspiciousLift,
  scoreLift,
  isWeakLift,
  compareLift,
  probeFingerprint,
};
