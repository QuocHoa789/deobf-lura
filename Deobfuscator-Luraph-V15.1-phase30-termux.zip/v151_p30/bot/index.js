'use strict';

const { Client, GatewayIntentBits, REST, Routes, SlashCommandBuilder } = require('discord.js');
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const os = require('os');
const { spawn } = require('child_process');
const readline = require('readline');
const crypto = require('crypto');

const ROOT = path.resolve(__dirname, '..');
const DEOB = path.join(ROOT, 'deob.js');
const MAX_BYTES = Number(process.env.MAX_FILE_MB || 8) * 1024 * 1024;
const JOB_TIMEOUT_MS = Number(process.env.DEOB_TIMEOUT_MS || 60 * 60 * 1000);
const PREFIX = process.env.BOT_PREFIX || '.';
const PLAYER_TOKEN_FILE = path.join(__dirname, 'data', 'player_tokens.json');
const TOKEN_PREFIX = 'PLR';
const TOKEN_BYTES = 18;
const OWNER_IDS = new Set([
  '1188496254464970872',
  '1486380909736366120'
]);

const TOKEN_ADMIN_IDS = OWNER_IDS;


function getToken() {
  if (process.env.DISCORD_TOKEN) return Promise.resolve(process.env.DISCORD_TOKEN.trim());
  if (!process.stdin.isTTY) return Promise.reject(new Error('DISCORD_TOKEN is not set and stdin is not interactive.'));
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise((resolve, reject) => {
    rl.question('Enter Discord bot token: ', answer => {
      rl.close();
      const token = answer.trim();
      token ? resolve(token) : reject(new Error('Empty Discord token.'));
    });
  });
}

function generatePlayerToken() {
  return `${TOKEN_PREFIX}_${crypto.randomBytes(TOKEN_BYTES).toString('base64url')}`;
}

function isOwner(userId) {
  return OWNER_IDS.has(String(userId));
}

async function loadPlayerTokens() {
  try {
    const raw = await fsp.readFile(PLAYER_TOKEN_FILE, 'utf8');
    const data = JSON.parse(raw);
    return data && typeof data === 'object' ? data : {};
  } catch (e) {
    if (e.code === 'ENOENT') return {};
    throw e;
  }
}

async function savePlayerTokens(tokens) {
  await fsp.mkdir(path.dirname(PLAYER_TOKEN_FILE), { recursive: true });
  const temp = `${PLAYER_TOKEN_FILE}.tmp-${process.pid}`;
  await fsp.writeFile(temp, JSON.stringify(tokens, null, 2) + '\n', { mode: 0o600 });
  await fsp.rename(temp, PLAYER_TOKEN_FILE);
}

function normalizePlayerRecord(userId, current) {
  if (!current || typeof current !== 'object') {
    return { userId: String(userId), tokens: [] };
  }

  // Migrate the old single-token format from v2 automatically.
  if (typeof current.token === 'string') {
    return {
      userId: String(userId),
      username: current.username || undefined,
      tokens: current.active === false ? [] : [{ token: current.token, createdAt: current.createdAt || new Date().toISOString(), usedAt: null }]
    };
  }

  const tokens = Array.isArray(current.tokens)
    ? current.tokens.filter(entry => entry && typeof entry.token === 'string')
        .map(entry => ({
          token: entry.token,
          createdAt: entry.createdAt || new Date().toISOString(),
          usedAt: entry.usedAt || null
        }))
    : [];

  return {
    ...current,
    userId: String(userId),
    tokens
  };
}

function tokenMutation(task) {
  tokenMutation._queue = (tokenMutation._queue || Promise.resolve())
    .catch(() => {})
    .then(task);
  return tokenMutation._queue;
}

async function issuePlayerToken(user) {
  return tokenMutation(async () => {
    const tokens = await loadPlayerTokens();
    const record = normalizePlayerRecord(user.id, tokens[user.id]);
    const entry = {
      token: generatePlayerToken(),
      createdAt: new Date().toISOString(),
      usedAt: null
    };
    record.username = user.username;
    record.tokens.push(entry);
    tokens[user.id] = record;
    await savePlayerTokens(tokens);
    return entry.token;
  });
}

async function getAvailablePlayerTokens(userId) {
  const tokens = await loadPlayerTokens();
  const record = normalizePlayerRecord(userId, tokens[userId]);
  return record.tokens.filter(entry => !entry.usedAt);
}

async function consumePlayerToken(userId) {
  if (isOwner(userId)) return { owner: true, token: null };

  return tokenMutation(async () => {
    const tokens = await loadPlayerTokens();
    const record = normalizePlayerRecord(userId, tokens[userId]);
    const entry = record.tokens.find(item => !item.usedAt);
    if (!entry) return { owner: false, token: null };

    entry.usedAt = new Date().toISOString();
    tokens[userId] = record;
    await savePlayerTokens(tokens);
    return { owner: false, token: entry.token };
  });
}

function isTokenAdmin(userId) {
  return TOKEN_ADMIN_IDS.has(String(userId));
}


function safeName(name) {
  const base = path.basename(name || 'input.lua').replace(/[^a-zA-Z0-9._-]/g, '_');
  if (!/\.(lua|luau|txt)$/i.test(base)) return `${base}.lua`;
  return base;
}

function runDeob(input, output, args = []) {
  return new Promise((resolve, reject) => {
    const child = spawn(process.execPath, [DEOB, input, '-o', output, ...args], {
      cwd: ROOT,
      stdio: ['ignore', 'pipe', 'pipe'],
      env: Object.assign({}, process.env, { PYTHONUNBUFFERED: '1' }),
      detached: process.platform !== 'win32' // own process group so we can kill python/luau children too
    });
    let stdout = '';
    let stderr = '';
    let timedOut = false;
    const killTree = () => {
      try { process.platform !== 'win32' ? process.kill(-child.pid, 'SIGKILL') : child.kill('SIGKILL'); }
      catch { try { child.kill('SIGKILL'); } catch {} }
    };
    const timer = setTimeout(() => { timedOut = true; killTree(); }, JOB_TIMEOUT_MS);
    child.stdout.on('data', d => { stdout += d.toString(); if (stdout.length > 12000) stdout = stdout.slice(-12000); });
    child.stderr.on('data', d => {
      const t = d.toString();
      process.stderr.write(t);
      stderr += t; if (stderr.length > 20000) stderr = stderr.slice(-20000);
    });
    child.on('error', err => { clearTimeout(timer); reject(err); });
    child.on('close', (code, signal) => {
      clearTimeout(timer);
      const tail = stderr.slice(-1500);
      if (timedOut) return reject(new Error(`timed out after ${Math.round(JOB_TIMEOUT_MS / 60000)} minutes (raise DEOB_TIMEOUT_MS)\n${tail}`));
      if (code === 0 && fs.existsSync(output)) return resolve({ stdout, stderr });
      const why = signal ? `killed by ${signal}${signal === 'SIGKILL' ? ' (likely out of memory)' : ''}` : `exit code ${code}`;
      reject(new Error(`deob.js ${why}\n${tail}`));
    });
  });
}

async function downloadAttachment(url, dest, size) {
  if (size && size > MAX_BYTES) throw new Error(`File is too large. Limit: ${MAX_BYTES / 1024 / 1024} MB.`);
  const res = await fetch(url, { redirect: 'follow' });
  if (!res.ok) throw new Error(`Download failed: HTTP ${res.status}`);
  const len = Number(res.headers.get('content-length') || 0);
  if (len > MAX_BYTES) throw new Error(`File is too large. Limit: ${MAX_BYTES / 1024 / 1024} MB.`);
  const buf = Buffer.from(await res.arrayBuffer());
  if (buf.length > MAX_BYTES) throw new Error(`File is too large. Limit: ${MAX_BYTES / 1024 / 1024} MB.`);
  await fsp.writeFile(dest, buf);
}

function isAllowed(name) {
  return /\.(lua|luau|txt)$/i.test(name || '');
}

async function processFile(attachment, mode) {
  const dir = await fsp.mkdtemp(path.join(os.tmpdir(), 'luraph-discord-'));
  const input = path.join(dir, safeName(attachment.name));
  const output = path.join(dir, 'deobfuscated.luau');
  try {
    if (!isAllowed(attachment.name)) throw new Error('Only .lua, .luau or .txt files are accepted.');
    await downloadAttachment(attachment.url, input, attachment.size);
    const args = mode === 'trace' ? ['--no-devirt'] : [];
    const logs = await runDeob(input, output, args);
    return { output, logs, dir };
  } catch (e) {
    await fsp.rm(dir, { recursive: true, force: true }).catch(() => {});
    throw e;
  }
}

const slash = new SlashCommandBuilder()
  .setName('deobf')
  .setDescription('Deobfuscate a Lua/Luau file using the bundled Luraph engine')
  .addAttachmentOption(o => o.setName('file').setDescription('Lua/Luau file').setRequired(true))
  .addStringOption(o => o.setName('mode').setDescription('Processing mode').setRequired(false)
    .addChoices({ name: 'Full devirtualization', value: 'full' }, { name: 'Behavior trace', value: 'trace' }));

const detectSlash = new SlashCommandBuilder()
  .setName('detect')
  .setDescription('Detect the obfuscator used by a Lua/Luau file')
  .addAttachmentOption(o => o.setName('file').setDescription('Lua/Luau file').setRequired(true));

const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent] });
let busy = false;

async function registerCommands() {
  const rest = new REST({ version: '10' }).setToken(client.token);
  await rest.put(Routes.applicationCommands(client.user.id), { body: [slash.toJSON(), detectSlash.toJSON()] });
}

async function replyToken(message) {
  try {
    if (isOwner(message.author.id)) {
      return message.reply({
        content: '👑 Bạn là Owner. Player token của Owner là **vô hạn** — `.d` không tiêu hao token.',
        allowedMentions: { repliedUser: false }
      });
    }

    const available = await getAvailablePlayerTokens(message.author.id);
    if (!available.length) {
      return message.reply({
        content: '🔑 Bạn hiện có **0 player token**. Hãy nhờ Owner dùng `.t @player` để cấp thêm token.',
        allowedMentions: { repliedUser: false }
      });
    }

    const lines = available.map((entry, index) => `${index + 1}. ${entry.token}`);
    const shown = lines.slice(0, 20).join('\n');
    const more = lines.length > 20 ? `\n... và ${lines.length - 20} token khác.` : '';
    await message.reply({
      content: `🔑 **Player token của bạn**\n\`\`\`\n${shown}\n\`\`\`\n📦 Còn **${available.length} token**.\n⚠️ Mỗi lần dùng \.d sẽ tiêu hao 1 token.${more}`,
      allowedMentions: { repliedUser: false }
    });
  } catch (e) {
    await message.reply(`❌ Không thể đọc token: ${String(e.message || e).slice(0, 1200)}`);
  }
}


async function grantPlayerToken(message, mentions) {
  if (!isTokenAdmin(message.author.id)) {
    return message.reply('⛔ Chỉ Owner mới được dùng `.t @player`.');
  }
  const user = mentions.users.first();
  if (!user || user.bot) return message.reply('❌ Dùng: `.t @player` và mention một tài khoản Discord hợp lệ.');
  try {
    const token = await issuePlayerToken(user);
    let delivered = false;
    try {
      await user.send(
        `🔑 **Bạn vừa được cấp 1 player token.**\n\`\`\`\n${token}\n\`\`\`\n📌 Token này dùng được **1 lần** cho `.d`.\n⚠️ Không chia sẻ token này cho người khác.`
      );
      delivered = true;
    } catch {}
    const deliveryNote = delivered ? 'Token đã được gửi qua DM.' : 'Không gửi được DM; người nhận dùng `.token` để xem token còn lại.';
    await message.reply({
      content: `✅ Đã cấp **1 player token** cho <@${user.id}>. ${deliveryNote}`,
      allowedMentions: { users: [user.id], repliedUser: false }
    });
  } catch (e) {
    await message.reply(`❌ Không thể cấp token: ${String(e.message || e).slice(0, 1200)}`);
  }
}

async function replyHelp(message) {
  if (isOwner(message.author.id)) {
    return message.reply({
      content: [
        '👑 **OWNER COMMANDS**',
        '',
        '`.help` — xem toàn bộ lệnh',
        '`.d` + file — deobf file (Owner vô hạn token)',
        '`.token` — xem token player còn lại',
        '`.t @player` — cấp 1 token cho player',
        '`.` — prefix mặc định',
        '',
        '**Slash commands hiện có:**',
        '`/deobf` — deobf bằng slash command',
        '`/detect` — detect obfuscator'
      ].join('\n'),
      allowedMentions: { repliedUser: false }
    });
  }

  return message.reply({
    content: [
      '📖 **COMMANDS**',
      '',
      '`.help` — xem hướng dẫn',
      '`.d` + file — deobf file',
      '`.token` — xem player token còn lại'
    ].join('\n'),
    allowedMentions: { repliedUser: false }
  });
}


async function handleDeob(interaction, attachment, mode) {
  if (!attachment || !isAllowed(attachment.name)) {
    return interaction.reply({ content: '❌ Chỉ nhận .lua, .luau hoặc .txt.', ephemeral: true });
  }
  if (busy) return interaction.reply({ content: '⏳ Bot đang xử lý file khác. Thử lại sau.', ephemeral: true });

  const consumed = await consumePlayerToken(interaction.user.id);
  if (!consumed.owner && !consumed.token) {
    return interaction.reply({ content: '⛔ Bạn đã hết player token. Hãy nhờ Owner dùng `.t @player` để cấp thêm.', ephemeral: true });
  }

  busy = true;
  await interaction.deferReply();
  let result;
  try {
    result = await processFile(attachment, mode);
    const stat = await fsp.stat(result.output);
    if (stat.size > 25 * 1024 * 1024) throw new Error('Output exceeds Discord upload limit for this bot workflow.');
    await interaction.editReply({ content: `✅ Hoàn tất: **${attachment.name}** — mode: **${mode}**`, files: [{ attachment: result.output, name: `${path.parse(attachment.name).name}.deobf.luau` }] });
  } catch (e) {
    const msg = String(e.message || e).slice(0, 1800);
    await interaction.editReply(`❌ Deobf thất bại:\n\`\`\`${msg}\`\`\``).catch(() => {});
  } finally {
    busy = false;
    if (result?.dir) await fsp.rm(result.dir, { recursive: true, force: true }).catch(() => {});
  }
}

client.once('ready', async () => {
  console.log(`[Discord] Logged in as ${client.user.tag}`);
  try { await registerCommands(); console.log('[Discord] Slash commands registered.'); }
  catch (e) { console.error('[Discord] Command registration failed:', e.message); }
});

client.on('interactionCreate', async interaction => {
  if (!interaction.isChatInputCommand()) return;
  if (interaction.commandName === 'deobf') {
    const attachment = interaction.options.getAttachment('file');
    const mode = interaction.options.getString('mode') || 'full';
    await handleDeob(interaction, attachment, mode);
  } else if (interaction.commandName === 'detect') {
    const attachment = interaction.options.getAttachment('file');
    if (!isAllowed(attachment?.name)) return interaction.reply({ content: '❌ Chỉ nhận .lua, .luau hoặc .txt.', ephemeral: true });
    const dir = await fsp.mkdtemp(path.join(os.tmpdir(), 'luraph-detect-'));
    const input = path.join(dir, safeName(attachment.name));
    try {
      await downloadAttachment(attachment.url, input, attachment.size);
      const { stdout, stderr } = await new Promise((resolve, reject) => {
        const child = spawn(process.execPath, [DEOB, input, '--detect'], { cwd: ROOT, stdio: ['ignore', 'pipe', 'pipe'] });
        let out = '', err = '';
        child.stdout.on('data', d => out += d); child.stderr.on('data', d => err += d);
        child.on('error', reject); child.on('close', code => code === 0 ? resolve({ stdout: out, stderr: err }) : reject(new Error(err || `exit ${code}`)));
      });
      await interaction.reply(`🔎 Result:\n\`\`\`${(stdout || stderr).trim().slice(0, 1800)}\`\`\``);
    } catch (e) { await interaction.reply(`❌ Detect failed: ${String(e.message || e).slice(0, 1600)}`); }
    finally { await fsp.rm(dir, { recursive: true, force: true }).catch(() => {}); }
  }
});

client.on('messageCreate', async message => {
  if (message.author.bot || !message.content.startsWith(PREFIX)) return;

  const parts = message.content.slice(PREFIX.length).trim().split(/\s+/);
  const cmd = (parts.shift() || '').toLowerCase();

  if (cmd === 'help') {
    return replyHelp(message);
  }

  if (cmd === 'token') {
    return replyToken(message);
  }

  if (cmd === 't') {
    return grantPlayerToken(message, message.mentions);
  }

  if (cmd === 'd') {
    const attachment = message.attachments.first();
    if (!attachment) return message.reply('❌ Đính kèm file `.lua/.luau/.txt` rồi dùng `.d`');
    if (!isAllowed(attachment.name)) return message.reply('❌ Chỉ nhận .lua, .luau hoặc .txt.');
    if (busy) return message.reply('⏳ Bot đang xử lý file khác.');

    const consumed = await consumePlayerToken(message.author.id);
    if (!consumed.owner && !consumed.token) {
      return message.reply('⛔ Bạn đã hết player token. Hãy nhờ Owner dùng `.t @player` để cấp thêm.');
    }

    busy = true;
    const status = await message.reply(`⏳ Đang deobfuscate...${consumed.owner ? ' 👑 Owner' : ' 🔑 -1 token'}`);
    let result;
    try {
      result = await processFile(attachment, 'full');
      await status.edit({ content: `✅ Hoàn tất **${attachment.name}**${consumed.owner ? ' — 👑 Owner vô hạn token' : ' — 🔑 đã dùng 1 token'}`, files: [{ attachment: result.output, name: `${path.parse(attachment.name).name}.deobf.luau` }] });
    } catch (e) {
      await status.edit(`❌ ${String(e.message || e).slice(0, 1800)}`).catch(() => {});
    } finally {
      busy = false;
      if (result?.dir) await fsp.rm(result.dir, { recursive: true, force: true }).catch(() => {});
    }
  }
});

getToken().then(token => client.login(token)).catch(err => { console.error(err.message); process.exit(1); });
