from obfuscators.base import Obfuscator, Job
from obfuscators.luraph_v15 import LuraphV15
from obfuscators.luraph_v15_1 import LuraphV151

PLUGINS = [
    LuraphV151(),
    LuraphV15(),
]
