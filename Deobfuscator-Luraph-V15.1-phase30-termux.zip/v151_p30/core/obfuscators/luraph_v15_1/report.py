"""Structured V15.1 research/report output.

The report intentionally separates static frontend facts, runtime capability,
and dynamic lift status so a PARTIAL runtime cannot be mistaken for PASS.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
import json
from typing import Any, Dict, Optional


@dataclass
class V151Report:
    profile: str = "luraph_v15_1"
    sample: Optional[str] = None
    phase: str = "phase30"
    static: Dict[str, Any] = field(default_factory=dict)
    runtime: Dict[str, Any] = field(default_factory=dict)
    dynamic: Dict[str, Any] = field(default_factory=dict)
    tests: Dict[str, Any] = field(default_factory=dict)
    status: str = "PARTIAL"
    generated_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def refresh_status(self) -> str:
        dyn = str(self.dynamic.get("status", "BLOCKED")).upper()
        if dyn == "PASS" and self.static.get("status") == "PASS":
            self.status = "PASS"
        elif dyn in {"BLOCKED", "PARTIAL", "FAIL"}:
            self.status = "PARTIAL" if self.static.get("status") != "FAIL" else "FAIL"
        return self.status

    def to_dict(self) -> Dict[str, Any]:
        self.refresh_status()
        return asdict(self)

    def write(self, path: str) -> None:
        with open(path, "w", encoding="utf-8", newline="\n") as f:
            json.dump(self.to_dict(), f, indent=2, sort_keys=True)
            f.write("\n")


def from_frontend(frontend_result: Any) -> V151Report:
    summary = frontend_result.summary()
    static = {
        "status": "PASS" if summary.get("dispatchers") >= 4 and summary.get("modes") == [40, 118, 142, 217] and summary.get("validation", {}).get("ok") else "PARTIAL",
        "summary": summary,
        "semantic": summary.get("semantic", {}),
    }
    return V151Report(static=static)
