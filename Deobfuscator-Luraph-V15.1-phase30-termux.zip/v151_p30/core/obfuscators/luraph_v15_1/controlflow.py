"""Conservative V15.1 PC/control-flow analysis.

The analyzer records observable PC behavior.  It never invents a concrete
successor when the source does not expose one unambiguously.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Dict, Optional
import re


@dataclass(frozen=True)
class PCFacts:
    explicit_jump: bool
    conditional: bool
    returns: bool
    reexecute: bool
    increments: bool
    decrements: bool
    concrete_target: Optional[int]
    confidence: str

    def to_dict(self):
        return asdict(self)


def analyze(source: str) -> PCFacts:
    t = re.sub(r"\s+", "", source or "")
    dec = bool(re.search(r"\b(?:e|pc)-=1\b", t))
    inc = bool(re.search(r"\b(?:e|pc)\+=1\b", t))
    ret = "return" in t
    cond = bool(re.search(r"\bif\b|\?:|and|or", t))
    # Only accept direct `pc=<integer>` or `e=<integer>` targets.
    m = re.search(r"\b(?:e|pc)=(-?\d+)\b", t)
    target = int(m.group(1)) if m else None
    jump = target is not None or bool(re.search(r"\b(?:e|pc)=[A-Za-z_]\w*\[", t))
    if dec:
        conf = "HIGH"
    elif target is not None:
        conf = "HIGH"
    elif jump or ret or cond:
        conf = "MEDIUM"
    else:
        conf = "LOW"
    return PCFacts(jump, cond, ret, dec, inc, dec, target, conf)


def expected_effect(source: str, base_effect: str) -> str:
    f = analyze(source)
    if f.reexecute:
        return "EXPAND_AND_REEXECUTE"
    if f.returns and base_effect == "RETURN":
        return "RETURN"
    if f.concrete_target is not None or f.explicit_jump:
        return "JUMP"
    if f.conditional and base_effect == "COND_JUMP":
        return "COND_JUMP"
    return base_effect
