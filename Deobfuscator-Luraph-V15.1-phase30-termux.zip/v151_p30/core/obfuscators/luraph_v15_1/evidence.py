"""Evidence and confidence reporting for V15.1 opcode recovery.

This module deliberately does not infer a semantic merely because a handler
contains a familiar token.  It records observable features and lets callers
separate VERIFIED/OBSERVED/UNKNOWN evidence.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any, Dict, Iterable, Mapping, Sequence
import re

@dataclass(frozen=True)
class HandlerEvidence:
    mode: int
    opcode: int
    source_length: int
    writes_instruction_stream: bool
    reexecutes: bool
    has_return: bool
    has_call: bool
    has_branch: bool
    has_table_access: bool
    has_upvalue_access: bool
    arithmetic_ops: tuple[str, ...]
    confidence: str

    def to_dict(self):
        return asdict(self)


def extract(source: str, mode: int, opcode: int) -> HandlerEvidence:
    t = re.sub(r"\s+", "", source or "")
    ops = tuple(x for x in ("+", "-", "*", "/", "%", "//") if x in t)
    stream = bool(re.search(r"(?:_|A|R|c|u|w|C)\[[^\]]+\]=", t))
    reexec = "e-=1" in t or "pc-=1" in t
    ret = "return" in t
    call = bool(re.search(r"(?:\)\(|\]\(|pcall\(|xpcall\()", t))
    branch = bool(re.search(r"\bif\b|\belseif\b|\belse\b", t))
    table = "[" in t and "]" in t
    upvalue = "getupvalue" in t or "setupvalue" in t or "upval" in t
    confidence = "HIGH" if reexec and stream else ("MEDIUM" if any((ret, call, branch, table)) else "LOW")
    return HandlerEvidence(int(mode), int(opcode), len(source or ""), stream, reexec,
                           ret, call, branch, table, upvalue, ops, confidence)


def audit_specs(specs: Mapping[int, Any], source_by_opcode: Mapping[int, str], mode: int) -> Dict[str, Any]:
    rows = []
    for opcode in sorted(specs):
        src = source_by_opcode.get(opcode, "")
        ev = extract(src, mode, opcode)
        spec = specs[opcode]
        rows.append({"opcode": opcode, "semantic": spec.semantic,
                     "spec_confidence": spec.confidence, "evidence": ev.to_dict()})
    return {"mode": int(mode), "count": len(rows), "rows": rows}
