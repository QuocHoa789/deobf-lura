"""Luraph v15.1 devirtualization compatibility profile.

Start from the v15 symbolic lifter and raise recovery ceilings modestly for
15.1's larger dispatcher/helper graphs. The underlying algorithms remain the
same until a 15.1-specific VM semantic divergence is demonstrated.
"""
import os
from obfuscators.luraph_v15 import devirt as _base

_DEFAULTS = {
    "DEVIRT_WALK_LIMIT": "450000",
    "DEVIRT_MAX_STATES": "1800000",
    "DEVIRT_RECOVERY_LIMIT": "350000",
    "DEVIRT_MAX_RECOVERY_ROUNDS": "24",
    "DEVIRT_RECOVERY_STALL": "20000",
}
for _k, _v in _DEFAULTS.items():
    if not os.environ.get(_k):
        os.environ[_k] = _v
        if hasattr(_base, _k):
            try:
                setattr(_base, _k, int(_v))
            except ValueError:
                pass

# Re-export the full v15 engine API so the existing bridge/backend can call it.
for _name in dir(_base):
    if not _name.startswith("_"):
        globals()[_name] = getattr(_base, _name)
