"""Conservative conversion from resolved V15.1 handlers to frontend IR."""
from __future__ import annotations

import re
from typing import Any, Dict, Mapping, Optional, Sequence

from .frontend_ir import Instruction, ProgramIR, instruction_from_spec
from .opcode_maps import classify, get_opcode_spec


def _rhs_operands(text: str):
    """Extract only obvious simple array operands; never invent missing fields."""
    out = []
    for m in re.finditer(r"(?:[A-Za-z_]\w*)\[([A-Za-z_]\w*)\]", text or ""):
        val = m.group(1)
        if val not in out:
            out.append(val)
        if len(out) >= 3:
            break
    return tuple(out)


def normalize_handler(mode: int, pc: int, opcode: int, handler: Mapping[str, Any], *, source: str = "") -> Instruction:
    spec = classify(mode, opcode, handler, source=source)
    operands = _rhs_operands(source)
    diagnostic = None
    if spec.semantic == "UNKNOWN":
        diagnostic = "unknown V15.1 opcode mode=%d opcode=%d pc=%d" % (mode, opcode, pc)
    return instruction_from_spec(mode, pc, opcode, spec, operands=operands,
                                 source_location=handler.get("location"), diagnostic=diagnostic)


def normalize_dispatch(disp: Mapping[str, Any], lines: Optional[Sequence[str]] = None,
                       *, max_op: int = 256) -> ProgramIR:
    mode = disp.get("mode")
    if mode is None:
        raise ValueError("V15.1 dispatcher has no detected backend mode")
    from . import vmmap
    from obfuscators.luraph_v15 import vmmap as base_vmmap

    program = ProgramIR(int(mode), metadata={
        "family": disp.get("family"),
        "arr": disp.get("arr"),
        "pc_var": disp.get("pc"),
        "unknown_opcode_limit": max_op,
    })
    for op in range(max_op):
        block = vmmap.resolve(disp["tree"], disp["op"], op)
        if block is None:
            continue
        source = base_vmmap.text_of(lines, block) if lines is not None else ""
        program.append(normalize_handler(int(mode), op, op, block, source=source))
    return program
