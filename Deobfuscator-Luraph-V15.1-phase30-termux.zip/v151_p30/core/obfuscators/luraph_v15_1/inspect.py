"""Research CLI for inspecting a real V15.1 AST/dispatcher set.

Usage:
  python -m obfuscators.luraph_v15_1.inspect path/to/input.lua
  python -m obfuscators.luraph_v15_1.inspect path/to/input.lua --mode 40

This is a research/diagnostic command; it does not claim that the displayed
UNKNOWNs are executable semantics.
"""
from __future__ import annotations

import argparse
import os
import sys

from . import vmmap
from .opcode_maps import extract_opcode_specs
from .closure import build_closure_graph
from .normalize import normalize_dispatch
from .shared_ir import lower_program


def inspect(path: str, want_mode=None) -> int:
    root = vmmap.load_ast(path)
    with open(path, encoding="latin-1") as f:
        lines = f.read().split("\n")
    disps = vmmap.find_dispatchers(root)
    graph = build_closure_graph(root, dispatchers=disps)
    summary = graph.summary()
    print("[V15.1] closure-graph functions=%d captures=%d edges=%d dispatcher-functions=%d ambiguous-proto=%d" % (
        summary["functions"], summary["captures"], summary["closure_edges"],
        summary["dispatcher_functions"], summary["ambiguous_proto"]))
    print("[V15.1] dispatchers=%d" % len(disps))
    for idx, disp in enumerate(disps, 1):
        mode = disp.get("mode")
        family = disp.get("family")
        if want_mode is not None and mode != want_mode:
            continue
        specs = extract_opcode_specs(disp, lines)
        known = [s for s in specs.values() if s.semantic != "UNKNOWN"]
        unknown = [s for s in specs.values() if s.semantic == "UNKNOWN"]
        expands = [s for s in specs.values() if s.mutates_stream]
        print("[V15.1] dispatch=%d family=%s mode=%s op=%s arr=%s pc=%s handlers=%d known=%d unknown=%d expansions=%d" % (
            idx, family, mode, disp.get("op"), disp.get("arr"), disp.get("pc"),
            len(specs), len(known), len(unknown), len(expands)))
        for s in sorted(specs.values(), key=lambda x: x.opcode):
            if s.semantic == "UNKNOWN":
                continue
            flags = []
            if s.mutates_stream:
                flags.append("stream")
            if s.terminator:
                flags.append("term")
            suffix = " [%s]" % ",".join(flags) if flags else ""
            print("    op=%3d  %-20s pc=%-20s conf=%-7s%s" % (
                s.opcode, s.semantic, s.pc_effect, s.confidence, suffix))
        if unknown:
            print("    UNKNOWN:", ", ".join(str(s.opcode) for s in sorted(unknown, key=lambda x: x.opcode)))
        try:
            program = normalize_dispatch(disp, lines)
            lowered = lower_program(program)
            print("    IR: instructions=%d shared-nodes=%d" % (len(program.instructions), len(lowered.order)))
        except Exception as ex:
            print("    IR: PARTIAL (%s)" % ex)
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(prog="v151-inspect")
    ap.add_argument("source")
    ap.add_argument("--mode", type=int, choices=(40, 142, 217, 118))
    ns = ap.parse_args(argv)
    return inspect(ns.source, ns.mode)


if __name__ == "__main__":
    raise SystemExit(main())
