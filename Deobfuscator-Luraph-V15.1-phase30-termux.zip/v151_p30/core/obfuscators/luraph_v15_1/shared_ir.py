"""Lower V15.1 frontend IR into the project's version-neutral `core.ir`.

Phase 7 is intentionally a bridge, not the final devirtualizer.  Known simple
VM semantics become ordinary `core.ir` statements; unknown/ambiguous handlers
become explicit `Opaque` expressions so information is preserved.  Control
flow is represented with the existing `core.ir.Node`/`Next`/`Ret` classes and a
small State adapter, which makes the result consumable by the existing CFG
builder without changing the v15 engine.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple
import re

from .frontend_ir import Instruction, ProgramIR


@dataclass(frozen=True)
class SharedState:
    mode: int
    pc: int

    def key(self, _link=None):
        return (self.mode, self.pc, 0, (), 0, (), ())


@dataclass
class SharedProgram:
    mode: int
    order: List[Tuple[Tuple[Any, ...], Any]] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def instructions(self) -> List[Instruction]:
        return list(self.metadata.get("instructions", ()))


def _as_reg(value: Any):
    from luasym import Reg, Global, Const
    if isinstance(value, int):
        return Reg(value)
    if isinstance(value, str):
        m = re.fullmatch(r"r?(\d+)", value)
        if m:
            return Reg(int(m.group(1)))
        return Global(value)
    return Const(value)


def _expr(value: Any):
    from luasym import Const
    return _as_reg(value) if not isinstance(value, (dict, list, tuple)) else Const(value)


def _stmt_for_instruction(ins: Instruction):
    from ir import Assign, CallStmt, Opaque
    from luasym import Bin, Index, Reg, Upval, Const, Global, Multi, NewTable

    sem = ins.semantic
    a, b, c = ins.a, ins.b, ins.c
    if sem == "MOVE" and a is not None:
        return Assign(_as_reg(a), _as_reg(c if c is not None else b))
    if sem in {"ADD", "ADD_OR_CONTROL", "SUB", "MUL", "DIV", "MOD"} and a is not None:
        op = {"ADD": "+", "ADD_OR_CONTROL": "+", "SUB": "-", "MUL": "*", "DIV": "/", "MOD": "%"}[sem]
        return Assign(_as_reg(a), Bin(op, _as_reg(b), _as_reg(c)))
    if sem == "GETTABLE" and a is not None:
        return Assign(_as_reg(a), Index(_as_reg(b), _as_reg(c)))
    if sem in {"SETTABLE", "TABLE_WRITE"} and a is not None:
        return Assign(Index(_as_reg(a), _as_reg(b)), _as_reg(c))
    if sem == "GETUPVAL" and a is not None:
        idx = int(b) if isinstance(b, int) else 0
        return Assign(_as_reg(a), Upval(idx))
    if sem == "NEWTABLE" and a is not None:
        return Assign(_as_reg(a), NewTable())
    if sem == "LOAD_IMM" and a is not None:
        return Assign(_as_reg(a), Const(b))
    if sem == "LOAD" and a is not None:
        return Assign(_as_reg(a), Const(b))
    if sem in {"CALL", "CALL_MULTI", "MULTRET_CALL", "PCALL"} and a is not None:
        fn = _as_reg(a)
        return CallStmt("v151_%d" % ins.pc, fn, Multi([]))
    if sem == "NUM_CONVERT" and a is not None:
        return Assign(_as_reg(a), Global("tonumber"))
    if sem == "TOSTRING" and a is not None:
        return CallStmt("v151_tostring_%d" % ins.pc, Global("tostring"), Multi([_as_reg(c)] if c is not None else []))
    if a is not None:
        return Assign(_as_reg(a), Opaque("v151_unknown", ins.diagnostic or "%s opcode %d" % (sem, ins.opcode)))
    return Opaque("v151_unknown", ins.diagnostic or "%s opcode %d" % (sem, ins.opcode))


def _target(value: Any) -> Optional[int]:
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, str) and re.fullmatch(r"\d+", value):
        return int(value)
    return None


def _core_node_for(ins: Instruction, next_pc: Optional[int], mode: int):
    from ir import Node, Next, Ret, Opaque

    stmt = _stmt_for_instruction(ins)
    # Expansion is represented as a self re-execution edge. The materializer
    # will normally replace it before the CFG builder is invoked.
    if ins.pc_effect == "EXPAND_AND_REEXECUTE":
        state = SharedState(mode, ins.pc)
        return Node([stmt], outcome=Next(state))
    if ins.pc_effect == "RETURN" or ins.terminator or ins.semantic in {"RETURN", "CLOSURE_RETURN"}:
        return Node([stmt], outcome=Ret(None))
    if ins.pc_effect == "JUMP":
        target = _target(ins.a)
        state = SharedState(mode, target if target is not None else (next_pc if next_pc is not None else ins.pc))
        return Node([stmt], outcome=Next(state))
    if ins.pc_effect == "COND_JUMP":
        target = _target(ins.a)
        cond = _as_reg(ins.b if ins.b is not None else ins.c if ins.c is not None else ins.a)
        t = Node([], outcome=Next(SharedState(mode, target if target is not None else ins.pc)))
        e = Node([], outcome=Next(SharedState(mode, next_pc if next_pc is not None else ins.pc + 1)))
        return Node([stmt], cond=cond, then=t, els=e)
    return Node([stmt], outcome=Next(SharedState(mode, next_pc if next_pc is not None else ins.pc + 1)))


def lower_program(program: ProgramIR) -> SharedProgram:
    ordered = sorted(program.instructions, key=lambda x: (x.pc, x.opcode))
    result = SharedProgram(program.mode, metadata={"instructions": ordered, "unknowns": len(program.unknowns())})
    for i, ins in enumerate(ordered):
        next_pc = ordered[i + 1].pc if i + 1 < len(ordered) else None
        node = _core_node_for(ins, next_pc, program.mode)
        state = SharedState(program.mode, ins.pc)
        result.order.append((state.key(None), node))
    return result


def lower_dispatch(disp: Mapping[str, Any], lines: Optional[Sequence[str]] = None, *, max_op: int = 256) -> SharedProgram:
    from .normalize import normalize_dispatch
    return lower_program(normalize_dispatch(disp, lines, max_op=max_op))
