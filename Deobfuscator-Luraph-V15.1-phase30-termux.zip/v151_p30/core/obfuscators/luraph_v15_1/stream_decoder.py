"""Stateful V15.1 stream-decoder primitives recovered from the sample.

Phase 4 does two things that the Phase 3 primitive intentionally did not:

* keep an explicit byte-stream cursor/state object;
* model the 29-bit rolling mix and the aligned/tail transform used by the
  instruction-expansion helpers.

The codec is deliberately parameterised.  The supplied sample contains more
than one helper wrapper around the same bit-level operations, so the frontend
uses a small `BitOps` object instead of hard-coding a guessed helper name.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import ByteString, Callable, Iterable, List, Optional, Sequence, Tuple

MASK32 = 0xFFFFFFFF
MASK29 = 0x1FFFFFFF
MASK7 = 0x7F


@dataclass(frozen=True)
class DecodedWord:
    value: int
    next_pos: int


def _u32(value: int) -> int:
    return int(value) & MASK32


def band(a: int, b: int) -> int:
    return _u32(a) & _u32(b)


def bxor(a: int, b: int) -> int:
    return _u32(a) ^ _u32(b)


def lshift(a: int, b: int) -> int:
    return _u32(_u32(a) << int(b))


def rshift(a: int, b: int) -> int:
    return _u32(a) >> int(b)


@dataclass(frozen=True)
class BitOps:
    """Bit operations used by the observed V15.1 decoder family."""

    band: Callable[[int, int], int] = band
    bxor: Callable[[int, int], int] = bxor
    lshift: Callable[[int, int], int] = lshift
    rshift: Callable[[int, int], int] = rshift


def decode_compact_word(data: ByteString, pos: int = 0) -> DecodedWord:
    """Decode the exact 1..4-byte compact integer form seen in V15.1."""
    n = len(data)
    if pos < 0 or pos >= n:
        raise IndexError("compact word position outside input")
    b0 = data[pos]
    if b0 < 128:
        return DecodedWord(b0, pos + 1)
    if pos + 1 >= n:
        raise ValueError("truncated 2-byte compact word")
    b1 = data[pos + 1]
    if b1 < 128:
        return DecodedWord((b0 - 128) * 128 + b1, pos + 2)
    if pos + 2 >= n:
        raise ValueError("truncated 3-byte compact word")
    b2 = data[pos + 2]
    if b2 < 128:
        return DecodedWord((b0 - 128) * 16384 + (b1 - 128) + b2 * 128, pos + 3)
    if pos + 3 >= n:
        raise ValueError("truncated 4-byte compact word")
    b3 = data[pos + 3]
    value = ((b0 - 128) * 2097152 +
             (b1 - 128) * 128 +
             (b2 - 128) * 16384 +
             (b3 % 128) +
             (b3 - (b3 % 128)) * 2097152)
    return DecodedWord(value, pos + 4)


def decode_compact_stream(data: ByteString, pos: int = 0, *, limit: int = 1_000_000) -> Tuple[List[int], int]:
    """Decode compact words until EOF or `limit` records.

    A truncated final record is reported rather than silently discarded.
    """
    out: List[int] = []
    p = pos
    for _ in range(limit):
        if p >= len(data):
            return out, p
        item = decode_compact_word(data, p)
        out.append(item.value)
        p = item.next_pos
    raise RuntimeError("compact stream limit exceeded")


def compact_width(value: int) -> int:
    value = int(value)
    if value < 0:
        raise ValueError("compact width requires a non-negative value")
    if value < 128:
        return 1
    if value < 16384:
        return 2
    if value < 2097152:
        return 3
    return 4


def split_packed(value: int, width_bits: int, ops: BitOps = BitOps()) -> Tuple[int, int]:
    """Split the sample's packed operand using low/high `width_bits`."""
    if width_bits <= 0 or width_bits > 21:
        raise ValueError("invalid packed width")
    mask = (1 << width_bits) - 1
    return ops.rshift(value, width_bits), ops.band(value, mask)


@dataclass
class StreamState:
    """Explicit state holder for decoded stream bytes."""

    data: bytes
    pos: int = 0
    rolling: int = 0
    records: int = 0
    max_records: int = 1_000_000
    metadata: dict = field(default_factory=dict)

    def read_u8(self) -> int:
        if self.pos >= len(self.data):
            raise EOFError("V15.1 stream exhausted")
        value = self.data[self.pos]
        self.pos += 1
        return value

    def read_compact(self) -> int:
        item = decode_compact_word(self.data, self.pos)
        self.pos = item.next_pos
        self.records += 1
        if self.records > self.max_records:
            raise RuntimeError("V15.1 stream record limit exceeded")
        return item.value

    def remaining(self) -> int:
        return len(self.data) - self.pos


def observed_mix_step(state: int, ops: BitOps = BitOps(), *, mask: int = MASK29) -> int:
    """One rolling step matching the 13/13/14 structure in the sample."""
    state = ops.band(ops.bxor(state, ops.lshift(state, 13)), mask)
    state = ops.bxor(state, ops.rshift(state, 13))
    state = ops.band(ops.bxor(state, ops.lshift(state, 14)), mask)
    return state


def decode_mixed_bytes(seed: int, count: int, *, ops: BitOps = BitOps(), mask: int = MASK29) -> bytes:
    """Generate bytes from the observed 29-bit rolling instruction mix.

    Each step exposes four 7-bit lanes (0, 7, 14, 21), exactly like the
    handlers that populate `c/y/R/A/_` in the supplied sample.
    """
    if count < 0:
        raise ValueError("negative decode count")
    state = _u32(seed)
    out = bytearray()
    while len(out) < count:
        state = observed_mix_step(state, ops, mask=mask)
        for shift in (0, 7, 14, 21):
            out.append(ops.band(ops.rshift(state, shift), MASK7))
            if len(out) >= count:
                break
    return bytes(out)


def transform_aligned_region(
    data: bytearray,
    start: int,
    end: int,
    key: int,
    *,
    word_transform: Callable[[int, int], int] = bxor,
    byte_transform: Callable[[int, int], int] = bxor,
    word_size: int = 4,
) -> None:
    """Apply the sample's aligned 4-byte + tail transformation in-place."""
    if not (0 <= start <= end <= len(data)):
        raise ValueError("invalid transform bounds")
    if word_size != 4:
        raise ValueError("V15.1 observed transform uses 4-byte words")
    aligned_end = end - ((end - start) % word_size)
    k = _u32(key)
    for p in range(start, aligned_end, word_size):
        raw = int.from_bytes(data[p:p + 4], "little")
        mixed = word_transform(raw, k) & MASK32
        data[p:p + 4] = mixed.to_bytes(4, "little")
    for p in range(aligned_end, end):
        data[p] = byte_transform(data[p], k) & 0xFF


def decode_chunk(
    state: StreamState,
    *,
    length: int,
    key: int,
    word_transform: Callable[[int, int], int] = bxor,
    byte_transform: Callable[[int, int], int] = bxor,
) -> bytes:
    """Read and transform one bounded chunk from `StreamState`."""
    if length < 0 or state.pos + length > len(state.data):
        raise ValueError("chunk exceeds V15.1 stream bounds")
    start = state.pos
    state.pos += length
    chunk = bytearray(state.data[start:state.pos])
    transform_aligned_region(chunk, 0, len(chunk), key,
                             word_transform=word_transform,
                             byte_transform=byte_transform)
    state.rolling = _u32(key)
    return bytes(chunk)
