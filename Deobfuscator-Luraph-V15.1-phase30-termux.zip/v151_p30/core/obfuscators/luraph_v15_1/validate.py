"""Deterministic validation of V15.1 frontend/shared IR invariants."""
from __future__ import annotations
from typing import Any, Dict

REQUIRED_MODES = {40, 118, 142, 217}
VALID_EFFECTS = {"NEXT", "JUMP", "COND_JUMP", "RETURN", "CALL", "ADVANCE", "EXPAND_AND_REEXECUTE", "UNKNOWN"}


def validate_frontend(result: Any) -> Dict[str, Any]:
    errors = []
    modes = set()
    instructions = 0
    unknowns = 0
    for p in result.programs:
        modes.add(int(p.mode))
        pcs = []
        for ins in p.instructions:
            instructions += 1
            pcs.append(ins.pc)
            if ins.mode != p.mode:
                errors.append(f"mode mismatch mode={p.mode} ins={ins.mode} pc={ins.pc}")
            if ins.pc_effect not in VALID_EFFECTS:
                errors.append(f"invalid pc effect {ins.pc_effect!r} at {p.mode}:{ins.pc}")
            if ins.semantic == "UNKNOWN":
                unknowns += 1
        if pcs != sorted(pcs):
            errors.append(f"program PCs are not sorted for mode {p.mode}")
    missing = sorted(REQUIRED_MODES - modes)
    if missing:
        errors.append(f"missing modes: {missing}")
    return {"ok": not errors, "errors": errors, "modes": sorted(modes),
            "instructions": instructions, "unknowns": unknowns}


def validate_shared(result: Any) -> Dict[str, Any]:
    errors = []
    nodes = 0
    for s in result.shared:
        for key, node in s.order:
            nodes += 1
            if not isinstance(key, tuple) or len(key) < 2:
                errors.append("invalid shared state key")
            if node is None:
                errors.append("null shared node")
    return {"ok": not errors, "errors": errors, "nodes": nodes}
