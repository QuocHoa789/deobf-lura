"""Dynamic V15.1 instruction materialisation and expansion.

The sample contains two important families of stream-mutating handlers:

1. packed-operand materialisation, followed by `pc -= 1` so the newly-written
   instruction is executed again;
2. block expansion where a rolling 29-bit mix generates four 7-bit lanes and
   writes them into the opcode/operand arrays.

This module models those operations explicitly and places hard limits around
all expansion loops.  It is intentionally independent of the AST parser so it
can be unit-tested with decoded records before the full sample is lifted.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, Iterable, List, Mapping, MutableMapping, Optional, Sequence, Tuple

from .frontend_ir import Instruction, ProgramIR
from .stream_decoder import BitOps, MASK29, MASK7, bxor, decode_mixed_bytes, rshift, split_packed


MAX_EXPANSION_STEPS = 100_000
MAX_GENERATED = 1_000_000


@dataclass
class VMRecord:
    pc: int
    opcode: int
    a: int
    r: int
    c: int
    u: Optional[int] = None
    w: Optional[int] = None
    extra: Tuple[int, ...] = ()


@dataclass
class ExpansionEvent:
    kind: str
    pc_before: int
    pc_after: int
    generated: int = 0
    reason: str = ""


@dataclass
class ExpansionState:
    records: Dict[int, VMRecord] = field(default_factory=dict)
    events: List[ExpansionEvent] = field(default_factory=list)
    visits: Dict[int, int] = field(default_factory=dict)
    steps: int = 0
    generated: int = 0
    max_steps: int = MAX_EXPANSION_STEPS
    max_generated: int = MAX_GENERATED

    def add(self, record: VMRecord) -> None:
        if self.generated >= self.max_generated:
            raise RuntimeError("V15.1 expansion output limit exceeded")
        self.records[record.pc] = record
        self.generated += 1

    def visit(self, pc: int) -> None:
        self.steps += 1
        if self.steps > self.max_steps:
            raise RuntimeError("V15.1 expansion step limit exceeded")
        self.visits[pc] = self.visits.get(pc, 0) + 1
        if self.visits[pc] > 64:
            raise RuntimeError("V15.1 expansion cycle detected at pc=%d" % pc)


def split_operands(packed: int, *, ops: BitOps = BitOps()) -> Tuple[int, int, int]:
    """Return `(width, high, low)` using the compact split seen in V15.1."""
    value = int(packed)
    width = 7 if value < 16384 else (14 if value < 2097152 else 21)
    high, low = split_packed(value, width, ops)
    return width, high, low


def materialize_packed_instruction(
    *,
    pc: int,
    old: VMRecord,
    packed: int,
    key: int,
    mode: int,
    masks: Tuple[int, int, int, int],
    ops: BitOps = BitOps(),
    opcode_override: Optional[int] = None,
) -> Tuple[VMRecord, ExpansionEvent]:
    """Materialise one packed instruction using the sample's exact field shape.

    The four constants in `masks` correspond to the four 7-bit XOR lanes used
    by the mode-specific handler.  Keeping them as data is important because
    V15.1 changes them between backend modes.
    """
    _width, high, low = split_operands(packed, ops=ops)
    op_lane, a_lane, c_lane, r_lane = masks
    opcode = ops.bxor(low, ops.band(ops.rshift(key, op_lane), MASK7))
    a = ops.bxor(high, ops.band(ops.rshift(key, a_lane), MASK7))
    c = ops.bxor(old.c, ops.band(key, MASK7))
    r = ops.bxor(old.r, ops.band(ops.rshift(key, r_lane), MASK7))
    record = VMRecord(
        pc=pc,
        opcode=int(opcode_override if opcode_override is not None else opcode),
        a=int(a), r=int(r), c=int(c), u=old.u, w=old.w, extra=old.extra,
    )
    return record, ExpansionEvent("MATERIALIZE", pc, pc - 1,
                                  generated=1, reason="packed operand + re-execute")


def expand_block(
    *,
    base_pc: int,
    seed: int,
    count: int,
    base: VMRecord,
    ops: BitOps = BitOps(),
    mask: int = MASK29,
    max_generated: int = MAX_GENERATED,
    existing: Optional[Callable[[int], VMRecord]] = None,
) -> List[VMRecord]:
    """Generate `count` records using the sample's 29-bit lane generator.

    The observed opcode-46/54-style handlers XOR each generated 7-bit lane
    into the destination arrays rather than simply assigning the lane.  The
    optional `existing` callback supplies those pre-existing destination
    records; the `base` record is used when it is not supplied.
    """
    if count < 0:
        raise ValueError("negative expansion count")
    if count > max_generated:
        raise RuntimeError("requested V15.1 expansion exceeds output limit")
    raw = decode_mixed_bytes(seed, count * 4, ops=ops, mask=mask)
    out: List[VMRecord] = []
    for i in range(count):
        p = i * 4
        old = existing(base_pc + i) if existing is not None else base
        out.append(VMRecord(
            pc=base_pc + i,
            opcode=ops.bxor(old.opcode, raw[p + 3]),
            a=ops.bxor(old.a, raw[p + 2]),
            r=ops.bxor(old.r, raw[p + 1]),
            c=ops.bxor(old.c, raw[p]),
            u=old.u,
            w=old.w,
            extra=old.extra,
        ))
    return out


def materialize_program(
    program: ProgramIR,
    resolver: Callable[[Instruction], Optional[Sequence[VMRecord]]],
    *,
    max_steps: int = MAX_EXPANSION_STEPS,
    max_generated: int = MAX_GENERATED,
) -> Tuple[ProgramIR, ExpansionState]:
    """Replace stream-expanding instructions using a caller-supplied resolver.

    `resolver` performs the V15.1-specific decode of one frontend instruction.
    It may return zero or more concrete VM records.  This keeps the expansion
    engine deterministic and separate from the AST/closure machinery.
    """
    state = ExpansionState(max_steps=max_steps, max_generated=max_generated)
    out = ProgramIR(program.mode, metadata=dict(program.metadata))

    for ins in program.instructions:
        state.visit(ins.pc)
        concrete = resolver(ins) if ins.mutates_stream or ins.pc_effect == "EXPAND_AND_REEXECUTE" else (None,)
        if concrete == (None,):
            out.append(ins)
            continue
        records = list(concrete or ())
        if not records:
            state.events.append(ExpansionEvent("DROP", ins.pc, ins.pc,
                                               reason="resolver returned no materialized instruction"))
            continue
        for rec in records:
            state.add(rec)
        # Keep the frontend instruction exactly once.  The concrete stream is
        # recorded in metadata and will be lowered into the shared IR only after
        # closure/proto recovery knows the target function/proto context.
        out.append(ins)
        state.events.append(ExpansionEvent(
            "EXPAND", ins.pc, ins.pc - 1 if ins.pc_effect == "EXPAND_AND_REEXECUTE" else ins.pc,
            generated=len(records),
            reason="resolver materialised dynamic stream",
        ))
    out.metadata["expansion_events"] = list(state.events)
    out.metadata["expanded_records"] = dict(state.records)
    return out, state
