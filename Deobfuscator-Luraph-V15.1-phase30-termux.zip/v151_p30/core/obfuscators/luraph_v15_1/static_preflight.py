"""AST-independent preflight fallback for environments without luau-ast."""
from __future__ import annotations
from .bootstrap import analyze_file, sample_text_contract


def run(path: str):
    facts = analyze_file(path)
    with open(path, "r", encoding="latin-1") as f:
        text = f.read()
    contract = sample_text_contract(text)
    return {
        "status": "PASS" if tuple(facts.modes) == (40, 142, 217, 118) and contract.get("v151_dispatchers") == 4 else "PARTIAL",
        "bootstrap": facts.to_dict(),
        "source_contract": contract,
        "ast_required_for": ["dispatcher AST mapping", "handler extraction", "shared IR lowering"],
    }
