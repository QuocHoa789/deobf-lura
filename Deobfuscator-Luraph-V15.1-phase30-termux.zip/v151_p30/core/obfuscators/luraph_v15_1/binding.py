"""Bind the V15.1 AST mapper into the proven V15 lifter, without modifying V15.

The V15 lifter keeps its implementation in ``obfuscators.luraph_v15.devirt``.
Its functions resolve the module-global ``vmmap`` at runtime, so a V15.1 job can
swap only that dependency for the lifetime of the job.  The original mapper and
source-cache are restored afterwards, which keeps mixed-profile test processes
safe.
"""
from __future__ import annotations

from contextlib import contextmanager
from typing import Iterator

from obfuscators.luraph_v15 import devirt as base_devirt
from . import vmmap as v151_vmmap
from .root_selection import ranked_ids


def _v151_vm_roots(prog):
    """Select the V15.1 payload VM using explicit runtime evidence first.

    Candidate order is deterministic and scored by ``root_selection``.
    ``root_probes`` are never promoted over positive root evidence. When the
    dump contains no usable candidate, the untouched V15 policy is preserved.
    """
    base_roots = getattr(base_devirt, "_vm_roots")
    by_vm = {}
    for key, cap in prog.dump.protos.items():
        if cap.get("__maker") is None:
            continue
        by_vm.setdefault(cap["__maker"], []).append((cap.get("__seq") or 0, key, cap))

    raw = prog.dump.raw or {}
    ranked = ranked_ids(raw, prog.dump.protos)
    if not ranked:
        return base_roots(prog)

    vms = sorted(by_vm.items(), key=lambda kv: min(x[0] for x in kv[1]))
    for tag, lst in vms:
        lst.sort(key=lambda x: (x[0], x[1]))

    for rc in ranked:
        value = str(rc)
        for tag, lst in vms:
            hit = next((x for x in lst if str(x[1]) == value), None)
            if hit is None:
                continue
            payload = tag
            lst.remove(hit)
            lst.insert(0, hit)
            vms.sort(key=lambda kv: kv[0] == payload)
            return vms, payload

    return base_roots(prog)


def _bind_common():
    base_devirt.vmmap = v151_vmmap
    if hasattr(base_devirt, "_SOURCE_CACHE"):
        base_devirt._SOURCE_CACHE = {}
    if hasattr(base_devirt, "_vm_roots"):
        base_devirt._vm_roots = _v151_vm_roots


@contextmanager
def bound_v151() -> Iterator[object]:
    old_vmmap = base_devirt.vmmap
    old_cache = getattr(base_devirt, "_SOURCE_CACHE", None)
    old_roots = getattr(base_devirt, "_vm_roots", None)
    _bind_common()
    try:
        yield base_devirt
    finally:
        base_devirt.vmmap = old_vmmap
        if old_cache is not None:
            base_devirt._SOURCE_CACHE = old_cache
        if old_roots is not None:
            base_devirt._vm_roots = old_roots


def activate_v151() -> object:
    """Activate V15.1 mapping for a short-lived bridge process.

    The bridge process handles one profile and then exits, so leaving the
    binding active is safe there.  Library callers should prefer ``bound_v151``
    for exception-safe restoration.
    """
    _bind_common()
    return base_devirt
