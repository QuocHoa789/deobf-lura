"""Version-neutral instruction IR produced by the Luraph v15.1 frontend.

This is deliberately lower-level than core.ir: it represents normalized VM
instructions before they are lowered into the project's symbolic IR/CFG.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional, Tuple


@dataclass(frozen=True)
class Instruction:
    mode: int
    pc: int
    opcode: int
    semantic: str
    a: Any = None
    b: Any = None
    c: Any = None
    extras: Tuple[Any, ...] = ()
    pc_effect: str = "NEXT"
    mutates_stream: bool = False
    terminator: bool = False
    confidence: str = "UNKNOWN"
    source_location: Optional[str] = None
    diagnostic: Optional[str] = None

    @property
    def operands(self) -> Tuple[Any, ...]:
        vals = (self.a, self.b, self.c) + tuple(self.extras)
        return tuple(v for v in vals if v is not None)


@dataclass
class ProgramIR:
    mode: int
    instructions: List[Instruction] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def append(self, ins: Instruction) -> None:
        if ins.mode != self.mode:
            raise ValueError("instruction mode mismatch: %r != %r" % (ins.mode, self.mode))
        self.instructions.append(ins)

    def unknowns(self) -> List[Instruction]:
        return [x for x in self.instructions if x.semantic == "UNKNOWN"]

    def diagnostics(self) -> List[str]:
        return [x.diagnostic for x in self.instructions if x.diagnostic]


def instruction_from_spec(mode: int, pc: int, opcode: int, spec, *, operands=(), source_location=None,
                          diagnostic=None) -> Instruction:
    vals = tuple(operands)
    return Instruction(
        mode=mode,
        pc=pc,
        opcode=opcode,
        semantic=spec.semantic,
        a=vals[0] if len(vals) > 0 else None,
        b=vals[1] if len(vals) > 1 else None,
        c=vals[2] if len(vals) > 2 else None,
        extras=tuple(vals[3:]),
        pc_effect=spec.pc_effect,
        mutates_stream=spec.mutates_stream,
        terminator=spec.terminator,
        confidence=spec.confidence,
        source_location=source_location,
        diagnostic=diagnostic,
    )
