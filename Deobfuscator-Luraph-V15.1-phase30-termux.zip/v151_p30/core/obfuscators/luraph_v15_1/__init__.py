import re
import sys

from obfuscators.base import Obfuscator

HEADER = re.compile(r"This file was protected using Luraph Obfuscator v(\d+)(?:\.(\d+))?")

class LuraphV151(Obfuscator):
    name = "luraph_v15_1"
    label = "Luraph v15.1"
    doc = "LURAPH-V15.1.md"

    def detect(self, source):
        m = HEADER.search(source[:500])
        if m:
            return 1.0 if (m.group(1), m.group(2)) == ("15", "1") else 0.0
        return 0.0

    def add_arguments(self, ap):
        g = ap.add_argument_group("Luraph v15.1")
        g.add_argument("--no-hooks", action="store_true",
                       help="do not instrument VM functions")
        g.add_argument("--max-runs", type=int, default=12)
        g.add_argument("--devirt-rounds", type=int, default=200)
        g.add_argument("--debug-v151", action="store_true",
                       help="print V15.1 dispatcher/opcode research diagnostics")
        g.add_argument("--v151-report", default=None,
                       help="write a structured V15.1 research report JSON")

    def deobfuscate(self, job):
        from obfuscators.luraph_v15_1 import driver
        return driver.run(job)
