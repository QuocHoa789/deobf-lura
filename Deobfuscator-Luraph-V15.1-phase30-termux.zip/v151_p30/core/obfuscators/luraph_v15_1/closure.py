"""Graph-based closure/proto recovery for the Luraph v15.1 frontend.

This module deliberately avoids the old v15 assumption that a closure maker's
second parameter is always the proto.  It builds a lexical function graph,
resolves captures by declaration identity, records function-assignment edges,
and scores proto-parameter candidates from actual AST usage.

The result is research data: ambiguous candidates remain ambiguous instead of
being silently promoted to a verified proto/upvalue relationship.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple
import re


def _loc(node: Mapping[str, Any]) -> str:
    value = node.get("location")
    return value if isinstance(value, str) else ""


def _name(node: Mapping[str, Any]) -> str:
    if node.get("type") == "AstExprLocal":
        local = node.get("local") or {}
        return str(local.get("name") or "")
    return str(node.get("name") or "")


def _local_id(node: Mapping[str, Any]) -> str:
    local = node.get("local") or {}
    return str(local.get("location") or local.get("name") or "")


def _node_key(node: Mapping[str, Any], index: int) -> str:
    loc = _loc(node)
    if loc:
        return "fn@%s" % loc
    return "fn#%d" % index


def _walk(node: Any):
    if isinstance(node, dict):
        yield node
        for value in node.values():
            yield from _walk(value)
    elif isinstance(node, list):
        for value in node:
            yield from _walk(value)


def _walk_direct(node: Any, out: List[Mapping[str, Any]]) -> None:
    """Walk within one function but never descend into nested functions."""
    if isinstance(node, dict):
        if node.get("type") == "AstExprFunction" and out:
            return
        out.append(node)
        for value in node.values():
            _walk_direct(value, out)
    elif isinstance(node, list):
        for value in node:
            _walk_direct(value, out)


def _expr_local(node: Mapping[str, Any]) -> Optional[str]:
    if node.get("type") != "AstExprLocal":
        return None
    return _local_id(node)


@dataclass(frozen=True)
class Capture:
    function_id: str
    local_id: str
    name: str
    owner_function_id: Optional[str]
    depth: int


@dataclass(frozen=True)
class ClosureEdge:
    maker_function_id: str
    child_function_id: str
    local_id: str
    local_name: str
    evidence: str = "direct-assignment"


@dataclass(frozen=True)
class ParamCandidate:
    function_id: str
    param_index: int
    name: str
    score: int
    reasons: Tuple[str, ...]


@dataclass
class FunctionInfo:
    function_id: str
    node: Mapping[str, Any]
    parent_id: Optional[str]
    params: List[Tuple[int, str, str]] = field(default_factory=list)
    declarations: Dict[str, str] = field(default_factory=dict)
    references: Dict[str, str] = field(default_factory=dict)
    captures: List[Capture] = field(default_factory=list)
    children: List[str] = field(default_factory=list)
    dispatcher: bool = False
    assigned_locals: List[str] = field(default_factory=list)
    proto_candidates: List[ParamCandidate] = field(default_factory=list)
    upvalue_candidates: List[ParamCandidate] = field(default_factory=list)

    @property
    def location(self) -> str:
        return _loc(self.node)

    @property
    def name(self) -> str:
        return self.function_id

    def best_proto(self, min_score: int = 3, min_margin: int = 2) -> Optional[ParamCandidate]:
        if not self.proto_candidates:
            return None
        first = self.proto_candidates[0]
        second = self.proto_candidates[1] if len(self.proto_candidates) > 1 else None
        if first.score < min_score:
            return None
        if second is not None and first.score - second.score < min_margin:
            return None
        return first


@dataclass
class ClosureGraph:
    functions: Dict[str, FunctionInfo]
    declarations: Dict[str, str]
    edges: List[ClosureEdge]
    metadata: Dict[str, Any] = field(default_factory=dict)

    def captures_for(self, function_id: str) -> List[Capture]:
        fn = self.functions[function_id]
        return list(fn.captures)

    def children_for(self, function_id: str) -> List[FunctionInfo]:
        return [self.functions[x] for x in self.functions[function_id].children if x in self.functions]

    def proto_for(self, function_id: str) -> Optional[ParamCandidate]:
        return self.functions[function_id].best_proto()

    def summary(self) -> Dict[str, int]:
        return {
            "functions": len(self.functions),
            "captures": sum(len(x.captures) for x in self.functions.values()),
            "closure_edges": len(self.edges),
            "dispatcher_functions": sum(1 for x in self.functions.values() if x.dispatcher),
            "ambiguous_proto": sum(1 for x in self.functions.values() if x.dispatcher and x.best_proto() is None),
        }


def _direct_nodes(fn_node: Mapping[str, Any]) -> List[Mapping[str, Any]]:
    out: List[Mapping[str, Any]] = []
    body = fn_node.get("body")
    if isinstance(body, dict):
        _walk_direct(body, out)
    return out


def _collect_direct_declarations(fn_node: Mapping[str, Any]) -> Dict[str, str]:
    decl: Dict[str, str] = {}
    for n in _direct_nodes(fn_node):
        typ = n.get("type")
        if typ == "AstExprFunction":
            continue
        if typ == "AstStatLocal":
            for var in n.get("vars") or []:
                lid = str(var.get("location") or var.get("name") or "")
                name = str(var.get("name") or "")
                if lid:
                    decl[lid] = name
        elif typ == "AstStatLocalFunction":
            var = n.get("name") or {}
            lid = str(var.get("location") or var.get("name") or "")
            name = str(var.get("name") or "")
            if lid:
                decl[lid] = name
        elif typ == "AstStatFor":
            var = n.get("var") or {}
            lid = str(var.get("location") or var.get("name") or "")
            if lid:
                decl[lid] = str(var.get("name") or "")
        elif typ == "AstStatForIn":
            for var in n.get("vars") or []:
                lid = str(var.get("location") or var.get("name") or "")
                if lid:
                    decl[lid] = str(var.get("name") or "")
    for i, arg in enumerate(fn_node.get("args") or []):
        lid = str(arg.get("location") or arg.get("name") or "")
        if lid:
            decl[lid] = str(arg.get("name") or "arg%d" % i)
    return decl


def _collect_direct_references(fn_node: Mapping[str, Any]) -> Dict[str, str]:
    refs: Dict[str, str] = {}
    for n in _direct_nodes(fn_node):
        if n.get("type") == "AstExprLocal":
            lid = _local_id(n)
            if lid:
                refs[lid] = _name(n)
    return refs


def _param_nodes(fn_node: Mapping[str, Any]) -> List[Tuple[int, str, str]]:
    out = []
    for i, arg in enumerate(fn_node.get("args") or []):
        out.append((i, str(arg.get("name") or "arg%d" % i), str(arg.get("location") or arg.get("name") or "")))
    return out


def _score_params(fn: FunctionInfo) -> Tuple[List[ParamCandidate], List[ParamCandidate]]:
    param_by_id = {lid: (idx, name) for idx, name, lid in fn.params}
    score: Dict[int, int] = {idx: 0 for idx, _, _ in fn.params}
    reasons: Dict[int, List[str]] = {idx: [] for idx, _, _ in fn.params}
    direct = _direct_nodes(fn.node)

    for n in direct:
        if n.get("type") != "AstExprIndexExpr":
            continue
        expr = n.get("expr") or {}
        lid = _expr_local(expr) if isinstance(expr, dict) else None
        if lid in param_by_id:
            idx, name = param_by_id[lid]
            score[idx] += 3
            reasons[idx].append("indexed-as-table")
            inner = expr
            parent_steps = 0
            while isinstance(inner, dict) and inner.get("type") == "AstExprIndexExpr":
                parent_steps += 1
                inner = inner.get("expr") or {}
            if parent_steps > 1:
                score[idx] += 2
                reasons[idx].append("nested-index")

    for n in direct:
        typ = n.get("type")
        if typ == "AstStatAssign":
            for var in n.get("vars") or []:
                lid = _expr_local(var) if isinstance(var, dict) else None
                if lid in param_by_id:
                    idx, _ = param_by_id[lid]
                    score[idx] += 2
                    reasons[idx].append("assignment-target")
        elif typ == "AstStatReturn":
            for value in n.get("list") or []:
                lid = _expr_local(value) if isinstance(value, dict) else None
                if lid in param_by_id:
                    idx, _ = param_by_id[lid]
                    score[idx] += 1
                    reasons[idx].append("returned")

    candidates = []
    for idx, name, _ in fn.params:
        candidates.append(ParamCandidate(fn.function_id, idx, name, score[idx], tuple(reasons[idx])))
    candidates.sort(key=lambda x: (-x.score, x.param_index))

    # Upvalue-list parameters tend to be iterated/indexed but are not normally
    # self-mutated as a proto table.  Keep a separate ranked view, but do not
    # claim a definitive role until the caller provides more evidence.
    ups = sorted(candidates, key=lambda x: (-x.score, x.param_index))
    return candidates, ups


def _find_function_contexts(root: Mapping[str, Any]) -> Tuple[Dict[str, Mapping[str, Any]], Dict[str, Optional[str]]]:
    funcs: Dict[str, Mapping[str, Any]] = {}
    parents: Dict[str, Optional[str]] = {}
    counter = [0]

    def walk(n: Any, parent: Optional[str]) -> None:
        if isinstance(n, dict):
            if n.get("type") == "AstExprFunction":
                counter[0] += 1
                fid = _node_key(n, counter[0])
                funcs[fid] = n
                parents[fid] = parent
                body = n.get("body")
                if isinstance(body, dict):
                    for child in body.get("body") or []:
                        walk(child, fid)
                return
            for value in n.values():
                walk(value, parent)
        elif isinstance(n, list):
            for value in n:
                walk(value, parent)
    walk(root, None)
    return funcs, parents


def _resolve_owner(local_id: str, current: str, declarations: Mapping[str, str], funcs: Mapping[str, FunctionInfo]) -> Optional[str]:
    owner = current
    while owner is not None:
        if local_id in funcs[owner].declarations:
            return owner
        owner = funcs[owner].parent_id
    return declarations.get(local_id)


def build_closure_graph(root: Mapping[str, Any], *, dispatchers: Optional[Sequence[Mapping[str, Any]]] = None) -> ClosureGraph:
    raw_funcs, parents = _find_function_contexts(root)
    functions: Dict[str, FunctionInfo] = {}
    global_decl_owner: Dict[str, str] = {}

    for fid, node in raw_funcs.items():
        fn = FunctionInfo(function_id=fid, node=node, parent_id=parents.get(fid), params=_param_nodes(node))
        fn.declarations = _collect_direct_declarations(node)
        fn.references = _collect_direct_references(node)
        functions[fid] = fn
        for lid in fn.declarations:
            # First lexical declaration wins in the global lookup; normal
            # resolution walks the parent chain so shadowing remains intact.
            global_decl_owner.setdefault(lid, fid)

    # Parent/child links.
    for fid, fn in functions.items():
        if fn.parent_id in functions:
            functions[fn.parent_id].children.append(fid)

    # Lexical captures.
    for fid, fn in functions.items():
        for lid, name in fn.references.items():
            if lid in fn.declarations:
                continue
            owner = _resolve_owner(lid, fn.parent_id or fid, global_decl_owner, functions)
            if owner is not None and owner != fid:
                depth = 1
                x = owner
                while x is not None and x != fid:
                    x = functions[x].parent_id if x in functions else None
                    depth += 1
                fn.captures.append(Capture(fid, lid, name, owner, max(1, depth - 1)))

    edges: List[ClosureEdge] = []
    child_by_loc = {fn.location: fid for fid, fn in functions.items() if fn.location}
    # Direct function-expression assignments are strong closure edges.
    def scan_assignment(n: Any, current_fid: Optional[str]) -> None:
        if isinstance(n, dict):
            if n.get("type") == "AstExprFunction":
                return
            if n.get("type") == "AstStatAssign" and current_fid in functions:
                vars_ = n.get("vars") or []
                vals = n.get("values") or []
                for var, value in zip(vars_, vals):
                    if not isinstance(value, dict) or value.get("type") != "AstExprFunction":
                        continue
                    child_id = child_by_loc.get(_loc(value))
                    lid = str(var.get("location") or var.get("name") or "")
                    lname = str(var.get("name") or "")
                    if child_id and lid:
                        functions[current_fid].assigned_locals.append(lid)
                        edges.append(ClosureEdge(current_fid, child_id, lid, lname))
            for value in n.values():
                scan_assignment(value, current_fid)
        elif isinstance(n, list):
            for value in n:
                scan_assignment(value, current_fid)

    for fid, fn in functions.items():
        body = fn.node.get("body")
        scan_assignment(body, fid)

    # Mark functions that contain dispatcher loops. Identity matching is used,
    # but only as evidence; it does not force proto parameter selection.
    if dispatchers:
        disp_nodes = {id(d.get("node")): d for d in dispatchers}
        for fid, fn in functions.items():
            if any(id(x) in disp_nodes for x in _walk(fn.node)):
                fn.dispatcher = True

    for fn in functions.values():
        fn.proto_candidates, fn.upvalue_candidates = _score_params(fn)

    return ClosureGraph(functions=functions, declarations=global_decl_owner, edges=edges,
                         metadata={"method": "lexical-owner + AST evidence", "heuristic": False})


def recover_closures(root: Mapping[str, Any], *, dispatchers: Optional[Sequence[Mapping[str, Any]]] = None) -> ClosureGraph:
    """Alias with an explicit research-facing name."""
    return build_closure_graph(root, dispatchers=dispatchers)
