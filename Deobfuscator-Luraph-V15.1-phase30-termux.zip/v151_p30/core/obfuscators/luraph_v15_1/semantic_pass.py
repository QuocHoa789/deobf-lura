"""Semantic confidence pass over normalized V15.1 frontend IR."""
from __future__ import annotations
from collections import Counter
from typing import Any, Dict, Iterable, List

from .controlflow import expected_effect
from .opcode_maps import get_opcode_spec


def audit_program(program: Any, source_by_pc: Dict[int, str] | None = None) -> Dict[str, Any]:
    source_by_pc = source_by_pc or {}
    errors: List[str] = []
    warnings: List[str] = []
    confidence = Counter()
    effects = Counter()
    semantic = Counter()
    stream_mutations = 0
    terminators = 0
    for ins in program.instructions:
        semantic[ins.semantic] += 1
        confidence[ins.confidence] += 1
        effects[ins.pc_effect] += 1
        if ins.mutates_stream:
            stream_mutations += 1
        if ins.terminator:
            terminators += 1
        src = source_by_pc.get(ins.pc, "")
        if src:
            want = expected_effect(src, ins.pc_effect)
            if want != ins.pc_effect:
                warnings.append(f"pc effect drift mode={ins.mode} pc={ins.pc}: {ins.pc_effect}->{want}")
        spec = get_opcode_spec(program.mode, ins.opcode)
        if spec.mode != program.mode:
            errors.append(f"opcode mode mismatch {program.mode}:{ins.opcode}")
    known = sum(v for k, v in semantic.items() if k != "UNKNOWN")
    total = len(program.instructions)
    return {
        "ok": not errors,
        "errors": errors,
        "warnings": warnings,
        "mode": int(program.mode),
        "instructions": total,
        "known": known,
        "unknown": total - known,
        "coverage": (known / total) if total else 0.0,
        "confidence": dict(confidence),
        "pc_effects": dict(effects),
        "semantics": dict(semantic),
        "stream_mutations": stream_mutations,
        "terminators": terminators,
    }


def audit_frontend(result: Any) -> Dict[str, Any]:
    rows = [audit_program(p) for p in result.programs]
    errors = [e for row in rows for e in row["errors"]]
    warnings = [w for row in rows for w in row["warnings"]]
    total = sum(r["instructions"] for r in rows)
    known = sum(r["known"] for r in rows)
    return {
        "ok": not errors,
        "errors": errors,
        "warnings": warnings,
        "programs": rows,
        "instructions": total,
        "known": known,
        "unknown": total - known,
        "coverage": known / total if total else 0.0,
    }
