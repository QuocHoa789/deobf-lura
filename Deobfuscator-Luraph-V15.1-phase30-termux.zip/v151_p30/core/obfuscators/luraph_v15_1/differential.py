"""Small deterministic differential model for V15.1 control/stream behavior.

This is not a VM emulator.  It provides a reference for the pieces that are
already specified structurally: PC transitions and re-execution after stream
materialization.  Runtime traces can feed the same model later.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable, List, Sequence, Tuple


@dataclass(frozen=True)
class Step:
    pc: int
    opcode: int
    effect: str
    next_pc: int | None


def apply_effect(pc: int, effect: str, *, target: int | None = None) -> int | None:
    if effect == "NEXT":
        return pc + 1
    if effect == "ADVANCE":
        return pc + 1
    if effect == "JUMP":
        return target
    if effect == "EXPAND_AND_REEXECUTE":
        return pc - 1
    if effect in ("RETURN", "CALL"):
        return None
    if effect == "COND_JUMP":
        return target
    return pc + 1


def replay(steps: Sequence[Tuple[int, int, str, int | None]], start_pc: int = 0, limit: int = 1000) -> List[Step]:
    """Replay an abstract effect stream without evaluating Lua values."""
    out: List[Step] = []
    pc = start_pc
    by_pc = {(p, o): eff for p, o, eff, _ in steps}
    targets = {(p, o): target for p, o, _, target in steps}
    seen = 0
    while pc is not None and seen < limit:
        key = next(((p, o) for p, o, _, _ in steps if p == pc), None)
        if key is None:
            break
        op = key[1]
        effect = by_pc[key]
        target = targets[key]
        nxt = apply_effect(pc, effect, target=target)
        out.append(Step(pc, op, effect, nxt))
        if nxt == pc - 1 and effect == "EXPAND_AND_REEXECUTE":
            # The model deliberately permits the caller to provide the expanded
            # instruction at the lower PC on the next replay pass.
            pc = nxt
        else:
            pc = nxt
        seen += 1
    return out
