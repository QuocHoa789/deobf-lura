# Luraph v15.1 compatibility profile

This profile is based on the v15 VM pipeline and is intentionally isolated so
15.1-specific changes can be added without destabilizing the v15 engine.

Observed in the supplied v15.1 sample:

- Header: `Luraph Obfuscator v15.1`.
- Top-level VM object is still created through `return setmetatable({...})`.
- The sample contains multiple flattened `while true do` dispatch loops.
- Opcode handlers continue to be selected through nested numeric comparisons.
- The VM uses the same broad family of Luau primitives (`buffer`, `bit32`,
  `coroutine`, `table`, `string`, `vector`) used by the existing v15 mapper.

The first implementation therefore reuses the v15 AST/IR/devirtualizer while
raising bounded recovery ceilings. A true 15.1 semantic fork should only be
added once a concrete failing 15.1 sample demonstrates a VM-shape mismatch.
