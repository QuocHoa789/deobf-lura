"""Termux/native-runtime capability checks for the Luraph V15.1 frontend.

This module never claims a dynamic lift succeeded.  It only checks whether the
native Luau + AST parser toolchain is available and whether the supplied sample
can be parsed by that parser.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import json
import os
import platform
import shutil
import stat
import subprocess
from typing import Dict, Optional, Sequence


@dataclass(frozen=True)
class ToolProbe:
    name: str
    path: Optional[str]
    exists: bool
    executable: bool
    file_type: str
    version: str
    error: Optional[str] = None


@dataclass(frozen=True)
class RuntimeProbe:
    platform: str
    termux: bool
    luau: ToolProbe
    luau_ast: ToolProbe
    sample_parse: str
    native_ready: bool

    def to_dict(self) -> Dict[str, object]:
        return asdict(self)


def _run_capture(argv: Sequence[str], timeout: float = 8.0) -> tuple[str, str, int]:
    p = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                       text=True, timeout=timeout, check=False)
    return p.stdout.strip(), p.stderr.strip(), p.returncode


def _file_type(path: Optional[str]) -> str:
    if not path:
        return "missing"
    try:
        out, err, rc = _run_capture(["file", "-b", path])
        if rc == 0 and out:
            return out
        return err or "unknown"
    except Exception as ex:
        return "unavailable: %s" % ex


def _tool_probe(name: str, path: Optional[str]) -> ToolProbe:
    if not path:
        return ToolProbe(name, None, False, False, "missing", "", "not found")
    exists = os.path.exists(path)
    executable = os.access(path, os.X_OK)
    if not exists:
        return ToolProbe(name, path, False, False, "missing", "", "path does not exist")
    if not executable:
        return ToolProbe(name, path, True, False, _file_type(path), "", "not executable")
    version = ""
    error = None
    for args in ([path, "--version"], [path, "-v"]):
        try:
            out, err, rc = _run_capture(args)
            if rc == 0 and (out or err):
                version = out or err
                break
        except Exception as ex:
            error = str(ex)
    return ToolProbe(name, path, True, True, _file_type(path), version, error)


def _candidate(root: str, binary: str, env_name: str) -> Optional[str]:
    override = os.environ.get(env_name)
    if override:
        return override
    local = os.path.join(root, "bin", binary)
    if os.path.isfile(local):
        return local
    return shutil.which(binary)


def _native_ok(probe: ToolProbe) -> bool:
    if not (probe.exists and probe.executable):
        return False
    t = (probe.file_type or "").lower()
    if "pe32" in t or "ms-dos" in t:
        return False
    return any(token in t for token in ("elf", "executable", "shared object"))


def parse_sample_with_ast(ast_path: Optional[str], sample_path: Optional[str]) -> str:
    if not ast_path or not sample_path:
        return "SKIP"
    if not (os.path.isfile(ast_path) and os.path.isfile(sample_path)):
        return "SKIP"
    try:
        out, err, rc = _run_capture([ast_path, sample_path], timeout=30)
    except Exception as ex:
        return "ERROR:%s" % ex
    if rc == 0:
        return "PASS"
    text = (err or out).strip().replace("\n", " ")
    return "FAIL:%s" % text[:280]


def probe(root: Optional[str] = None, sample_path: Optional[str] = None) -> RuntimeProbe:
    root = os.path.abspath(root or os.path.join(os.path.dirname(__file__), "..", "..", ".."))
    luau = _tool_probe("luau", _candidate(root, "luau", "DEOB_LUAU"))
    ast = _tool_probe("luau-ast", _candidate(root, "luau-ast", "DEOB_LUAU_AST"))
    termux = bool(os.environ.get("TERMUX_VERSION") or "com.termux" in os.environ.get("PREFIX", ""))
    parse = parse_sample_with_ast(ast.path if _native_ok(ast) else None, sample_path)
    ready = _native_ok(luau) and _native_ok(ast) and parse == "PASS"
    return RuntimeProbe(platform=platform.platform(), termux=termux, luau=luau,
                        luau_ast=ast, sample_parse=parse, native_ready=ready)


def main(argv=None) -> int:
    import argparse
    ap = argparse.ArgumentParser(prog="v151-runtime-probe")
    ap.add_argument("--root", default=None)
    ap.add_argument("--sample", default=None)
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)
    result = probe(args.root, args.sample)
    if args.json:
        print(json.dumps(result.to_dict(), indent=2, sort_keys=True))
    else:
        print("platform:", result.platform)
        print("termux:", result.termux)
        for tool in (result.luau, result.luau_ast):
            print("%s:" % tool.name, tool.path or "MISSING")
            print("  exists=%s executable=%s" % (tool.exists, tool.executable))
            print("  type=%s" % tool.file_type)
            print("  version=%s" % (tool.version or "unknown"))
            if tool.error:
                print("  error=%s" % tool.error)
        print("sample_parse:", result.sample_parse)
        print("native_ready:", result.native_ready)
    return 0 if result.native_ready else 2


if __name__ == "__main__":
    raise SystemExit(main())
