"""Luraph v15.1 opcode specifications and conservative handler extraction.

This module intentionally separates *mode* from *opcode*.  The current sample
shows four independent opcode spaces (40, 142, 217, 118), so a numeric opcode
must never be interpreted without its backend mode.

Only semantics that are directly supported by the supplied sample's handler
shapes are seeded below.  Everything else remains UNKNOWN until the handler
AST/source provides enough evidence.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Any, Dict, Iterable, Mapping, Optional, Sequence, Tuple
import re


PC_NEXT = "NEXT"
PC_JUMP = "JUMP"
PC_COND_JUMP = "COND_JUMP"
PC_RETURN = "RETURN"
PC_CALL = "CALL"
PC_ADVANCE = "ADVANCE"
PC_EXPAND = "EXPAND_AND_REEXECUTE"
PC_UNKNOWN = "UNKNOWN"


@dataclass(frozen=True)
class OpcodeSpec:
    opcode: int
    mode: int
    semantic: str = "UNKNOWN"
    operands: Tuple[str, ...] = ()
    pc_effect: str = PC_NEXT
    mutates_stream: bool = False
    terminator: bool = False
    confidence: str = "UNKNOWN"
    source: str = ""


# These are conservative, sample-observed facts rather than a claimed complete
# opcode table.  The entries below intentionally avoid semantics where the
# current evidence only identifies a broad family.
_SEED: Dict[int, Dict[int, OpcodeSpec]] = {
    40: {
        2: OpcodeSpec(2, 40, "SETTABLE", ("a", "b", "c"), source="sample"),
        4: OpcodeSpec(4, 40, "MOVE", ("a", "c"), source="sample"),
        5: OpcodeSpec(5, 40, "ADD", ("a", "b", "c"), source="sample"),
        9: OpcodeSpec(9, 40, "UNPACK", ("a", "b", "c"), source="sample"),
        13: OpcodeSpec(13, 40, "MUL", ("a", "b", "c"), source="sample"),
        18: OpcodeSpec(18, 40, "GETTABLE", ("a", "b", "c"), source="sample"),
        20: OpcodeSpec(20, 40, "LOAD", ("a", "b"), source="sample"),
        27: OpcodeSpec(27, 40, "MULTRET_CALL", ("a", "b", "c"), pc_effect=PC_CALL, source="sample"),
        30: OpcodeSpec(30, 40, "COMPARE", ("a", "b", "c"), source="sample"),
        41: OpcodeSpec(41, 40, "NUM_CONVERT", ("a", "b"), source="sample"),
        43: OpcodeSpec(43, 40, "JUMP", ("a",), pc_effect=PC_JUMP, source="sample"),
        48: OpcodeSpec(48, 40, "GETUPVAL", ("a", "b"), source="sample"),
        50: OpcodeSpec(50, 40, "COND_JUMP", ("a", "b", "c"), pc_effect=PC_COND_JUMP, source="sample"),
        51: OpcodeSpec(51, 40, "CALL", ("a", "b", "c"), pc_effect=PC_CALL, source="sample"),
        60: OpcodeSpec(60, 40, "CALL_MULTI", ("a", "b", "c"), pc_effect=PC_CALL, source="sample"),
        65: OpcodeSpec(65, 40, "CALL", ("a", "b", "c"), pc_effect=PC_CALL, source="sample"),
        67: OpcodeSpec(67, 40, "ADD_OR_CONTROL", (), source="sample", confidence="MEDIUM"),
    },
    142: {
        23: OpcodeSpec(23, 142, "STATE_LOAD", ("a", "b"), source="sample"),
        24: OpcodeSpec(24, 142, "CLOSURE", ("a", "b"), source="sample"),
        25: OpcodeSpec(25, 142, "MUL", ("a", "b", "c"), source="sample"),
        27: OpcodeSpec(27, 142, "ADD", ("a", "b", "c"), source="sample"),
        34: OpcodeSpec(34, 142, "NEWTABLE", ("a",), source="sample"),
        37: OpcodeSpec(37, 142, "TABLE_WRITE", ("a", "b", "c"), source="sample", confidence="MEDIUM"),
        41: OpcodeSpec(41, 142, "COMPARE", ("a", "b", "c"), source="sample"),
        51: OpcodeSpec(51, 142, "CALL_MULTI", ("a", "b", "c"), pc_effect=PC_CALL, source="sample"),
    },
    217: {
        3: OpcodeSpec(3, 217, "MOD", ("a", "b", "c"), source="sample"),
        10: OpcodeSpec(10, 217, "ASSERT", ("a",), source="sample"),
        15: OpcodeSpec(15, 217, "LOAD_IMM", ("a", "u"), source="sample"),
        20: OpcodeSpec(20, 217, "TYPE", ("a", "c"), source="sample", confidence="MEDIUM"),
        34: OpcodeSpec(34, 217, "NEWTABLE", ("a",), source="sample"),
        43: OpcodeSpec(43, 217, "JUMP", ("a",), pc_effect=PC_JUMP, source="sample"),
        48: OpcodeSpec(48, 217, "GETUPVAL", ("a", "b"), source="sample"),
        58: OpcodeSpec(58, 217, "STATE", ("a",), source="sample", confidence="MEDIUM"),
        60: OpcodeSpec(60, 217, "CALL", ("a", "b", "c"), pc_effect=PC_CALL, source="sample"),
        65: OpcodeSpec(65, 217, "CALL", ("a", "b", "c"), pc_effect=PC_CALL, source="sample"),
        70: OpcodeSpec(70, 217, "TOSTRING", ("a", "c"), source="sample"),
        74: OpcodeSpec(74, 217, "COMPARE", ("a", "b", "c"), source="sample"),
        75: OpcodeSpec(75, 217, "RETURN_OR_CALL", (), pc_effect=PC_CALL, source="sample", confidence="MEDIUM"),
    },
    118: {
        46: OpcodeSpec(46, 118, "CALL", ("a", "b", "c"), pc_effect=PC_CALL, source="sample"),
        51: OpcodeSpec(51, 118, "CALL_OR_RETURN", (), pc_effect=PC_CALL, source="sample", confidence="MEDIUM"),
        53: OpcodeSpec(53, 118, "JUMP", ("a",), pc_effect=PC_JUMP, source="sample"),
        56: OpcodeSpec(56, 118, "CONTROL", (), source="sample", confidence="MEDIUM"),
        65: OpcodeSpec(65, 118, "CALL", ("a", "b", "c"), pc_effect=PC_CALL, source="sample"),
        70: OpcodeSpec(70, 118, "PCALL", ("a", "b", "c"), pc_effect=PC_CALL, source="sample"),
        73: OpcodeSpec(73, 118, "FUNCTION_STATE", ("a",), source="sample", confidence="MEDIUM"),
        75: OpcodeSpec(75, 118, "CAPTURE", ("a",), source="sample", confidence="MEDIUM"),
    },
}

V151_OPCODE_MAP: Mapping[int, Mapping[int, OpcodeSpec]] = _SEED

_STREAM_MUTATION_PATTERNS = (
    "_[",
    "A[",
    "R[",
    "c[",
)


def get_opcode_spec(mode: int, opcode: int) -> OpcodeSpec:
    mode_map = V151_OPCODE_MAP.get(int(mode), {})
    return mode_map.get(int(opcode), OpcodeSpec(int(opcode), int(mode)))


def opcode_name(mode: int, opcode: int) -> str:
    return get_opcode_spec(mode, opcode).semantic


def _flatten_text(node: Any) -> str:
    if node is None:
        return ""
    if isinstance(node, str):
        return node
    if isinstance(node, dict):
        if "text" in node and isinstance(node["text"], str):
            return node["text"]
        return " ".join(_flatten_text(v) for v in node.values())
    if isinstance(node, list):
        return " ".join(_flatten_text(v) for v in node)
    return str(node)


def _source_features(text: str) -> Dict[str, bool]:
    t = re.sub(r"\s+", "", text or "")
    return {
        "return": "return" in t,
        "break": "break" in t,
        "jump_pc": "e=R[e]" in t or "e=W[R[e]]" in t,
        "expand": any(p in t for p in _STREAM_MUTATION_PATTERNS) and "e-=1" in t,
        "call": ")(" in t or "](" in t,
        "newtable": "={}" in t,
        "settable": "][" in t and "=" in t,
        "add": "+" in t,
        "mul": "*" in t,
        "div": "/" in t,
        "mod": "%" in t,
        "compare": "<" in t or ">" in t or "==" in t or "~=" in t,
        "tostring": "tostring" in t,
    }


def classify(mode: int, opcode: int, handler: Any = None, *, source: str = "") -> OpcodeSpec:
    """Return a conservative spec, using the sample seed then local evidence.

    A seeded semantic is preserved.  Otherwise simple handler-shape evidence
    may raise a narrow classification; ambiguous cases remain UNKNOWN.
    """
    base = get_opcode_spec(mode, opcode)
    if base.semantic != "UNKNOWN":
        if source or handler is not None:
            feats = _source_features(source or _flatten_text(handler))
            if feats["expand"] and not base.mutates_stream:
                return replace(base, mutates_stream=True, pc_effect=PC_EXPAND,
                               confidence="HIGH", source=base.source or "handler")
            if feats["return"] and not base.terminator:
                # Do not rewrite call-family semantics merely because a helper
                # contains a return path; mark only explicit return handlers.
                if base.semantic.startswith("RETURN"):
                    return replace(base, terminator=True, pc_effect=PC_RETURN)
        return base

    text = source or _flatten_text(handler)
    feats = _source_features(text)
    if feats["expand"]:
        return OpcodeSpec(opcode, mode, "STREAM_EXPAND", (), PC_EXPAND, True, False, "HIGH", "handler")
    if feats["return"] and not feats["call"]:
        return OpcodeSpec(opcode, mode, "RETURN", (), PC_RETURN, False, True, "MEDIUM", "handler")
    if feats["newtable"]:
        return OpcodeSpec(opcode, mode, "NEWTABLE", (), PC_NEXT, False, False, "MEDIUM", "handler")
    if feats["tostring"]:
        return OpcodeSpec(opcode, mode, "TOSTRING", (), PC_NEXT, False, False, "MEDIUM", "handler")
    if feats["call"] and feats["return"]:
        return OpcodeSpec(opcode, mode, "CALL", (), PC_CALL, False, True, "LOW", "handler")
    return base


def extract_opcode_specs(disp: Mapping[str, Any], lines: Optional[Sequence[str]] = None,
                          *, max_op: int = 256) -> Dict[int, OpcodeSpec]:
    """Resolve every reachable opcode and return mode-scoped specs.

    `disp` is the record from v15_1.vmmap.find_dispatchers().  Source snippets
    are optional; without them this reports seeded semantics and UNKNOWNs.
    """
    mode = disp.get("mode")
    if mode is None:
        return {}
    out: Dict[int, OpcodeSpec] = {}
    text_of = None
    if lines is not None:
        from obfuscators.luraph_v15 import vmmap as _base_vmmap
        text_of = _base_vmmap.text_of
    for op in range(max_op):
        blk = None
        try:
            # resolve() is intentionally supplied by the v15.1 vmmap caller;
            # importing lazily avoids an import cycle at module load time.
            from obfuscators.luraph_v15_1 import vmmap
            blk = vmmap.resolve(disp["tree"], disp["op"], op)
        except Exception:
            blk = None
        if blk is None:
            continue
        snippet = text_of(lines, blk) if text_of else ""
        out[op] = classify(int(mode), op, blk, source=snippet)
    return out


def mark_verified(spec: OpcodeSpec, reason: str) -> OpcodeSpec:
    return replace(spec, confidence="HIGH", source=reason)
