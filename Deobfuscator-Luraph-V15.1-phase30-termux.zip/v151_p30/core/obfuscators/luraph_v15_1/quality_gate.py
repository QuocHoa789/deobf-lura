"""Phase 21-25 deterministic quality gate."""
from __future__ import annotations
from typing import Any, Dict

from .bootstrap import MODES, analyze_file, sample_text_contract
from .handler_catalog import catalog_source


def evaluate_source(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="latin-1") as f:
        text = f.read()
    facts = analyze_file(path)
    contract = sample_text_contract(text)
    motifs = catalog_source(text)
    checks = {
        "all_modes": tuple(facts.modes) == tuple(MODES),
        "v151_dispatchers": contract.get("v151_dispatchers") == 4,
        "legacy_dispatchers": contract.get("legacy_dispatchers") == 4,
        "stream_mutation": motifs["stream_write"].count > 0,
        "reexecute": motifs["pc_reexecute"].count > 0,
        "materializer": motifs["materializer"].count > 0,
    }
    return {
        "status": "PASS" if all(checks.values()) else "PARTIAL",
        "checks": checks,
        "bootstrap": facts.to_dict(),
        "source_contract": contract,
        "motifs": {k: v.to_dict() for k, v in motifs.items()},
    }


def evaluate_frontend(frontend: Any) -> Dict[str, Any]:
    from .semantic_pass import audit_frontend
    audit = audit_frontend(frontend)
    modes = sorted({int(p.mode) for p in frontend.programs})
    ok = set(modes) == set(MODES) and audit["ok"]
    return {"status": "PASS" if ok else "PARTIAL", "modes": modes, "semantic": audit}
