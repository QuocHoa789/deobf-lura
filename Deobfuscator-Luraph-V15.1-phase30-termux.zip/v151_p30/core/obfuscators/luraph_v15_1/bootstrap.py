"""Conservative V15.1 bootstrap/runtime-state analysis.

This pass does not pretend to execute the decoder. It extracts the stable
bootstrap facts that are visible in the supplied protected source and exposes
them as structured metadata for the later runtime/devirt bridge.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Dict, List, Mapping, Optional, Sequence, Tuple
import re


MODES = (40, 142, 217, 118)


@dataclass(frozen=True)
class BootstrapFacts:
    blob_name: Optional[str]
    decoder_functions: Tuple[str, ...]
    decode_blob_expr: Optional[str]
    stream_state_names: Tuple[str, ...]
    modes: Tuple[int, ...]
    compact_constants: Tuple[int, ...]
    rolling_constants: Tuple[int, ...]
    has_buffer_fromstring: bool
    has_bit32_mix: bool
    materializer_hits: int
    reexecute_hits: int
    confidence: str

    def to_dict(self) -> Dict[str, object]:
        return asdict(self)


def _names(src: str) -> Tuple[Optional[str], Tuple[str, ...], Optional[str]]:
    # Prefer the exact sample shape, but keep this parser conservative.
    blob = None
    m = re.search(r"string\.sub\([^\n;]{0,120}?Y\.([A-Za-z_]\w*)\s*,\s*5\)", src)
    if m:
        blob = m.group(1)

    decoders: List[str] = []
    for name in ("ZV", "pV"):
        if re.search(r"(?:^|[;,])(?:local\s+)?" + re.escape(name) + r"\s*=\s*function", src):
            decoders.append(name)
    expr = None
    m = re.search(r"buffer\.fromstring\(([^\n;]{1,180})\)", src)
    if m:
        expr = m.group(1)
    return blob, tuple(decoders), expr


def analyze_source_text(src: str) -> BootstrapFacts:
    blob, decoders, expr = _names(src)
    modes = tuple(m for m in MODES if re.search(r"\bF\s*==\s*%d\b" % m, src))
    stream_names = []
    for name in ("C", "u", "s", "o"):
        if re.search(r"\b%s\s*=" % re.escape(name), src):
            stream_names.append(name)
    compact = tuple(x for x in (128, 16384, 2097152) if str(x) in src)
    rolling = tuple(x for x in (16843009, 54337324, 536870911) if str(x) in src)
    materializer_hits = len(re.findall(r"(?:A|R|c|_)\s*\[[^\]]+\]\s*=", src))
    reexecute_hits = len(re.findall(r"e\s*-\s*=\s*1\s*;", src))
    confidence = "HIGH" if len(modes) == 4 and decoders and expr else "MEDIUM"
    return BootstrapFacts(
        blob_name=blob,
        decoder_functions=decoders,
        decode_blob_expr=expr,
        stream_state_names=tuple(stream_names),
        modes=modes,
        compact_constants=compact,
        rolling_constants=rolling,
        has_buffer_fromstring="buffer.fromstring" in src,
        has_bit32_mix=any(x in src for x in ("bit32.bxor", "bit32.band", "bit32.rshift")),
        materializer_hits=materializer_hits,
        reexecute_hits=reexecute_hits,
        confidence=confidence,
    )


def analyze_file(path: str) -> BootstrapFacts:
    with open(path, "r", encoding="latin-1") as f:
        return analyze_source_text(f.read())


def sample_text_contract(src: str) -> Dict[str, int]:
    """Cheap source-only contract used when native luau-ast is unavailable."""
    legacy = len(re.findall(r"while\s+true\s+do\s+local\s+[A-Za-z_]\w*\s*=\s*[A-Za-z_]\w*\[[A-Za-z_]\w*\]\s*;\s*if\s+", src))
    predicate = len(re.findall(r"while\s+true\s+do\s+local\s+[A-Za-z_]\w*\s*=\s*[A-Za-z_]\w*\[[A-Za-z_]\w*\]\s*;\s*local\s+[A-Za-z_]\w*\s*=", src))
    modes = len([m for m in MODES if re.search(r"\bF\s*==\s*%d\b" % m, src)])
    return {"legacy_dispatchers": legacy, "v151_dispatchers": predicate, "dispatcher_shapes": legacy + predicate,
            "backend_modes": modes}
