"""Source-only V15.1 handler motif catalog.

This pass is intentionally AST-independent.  It does not claim to identify an
opcode from a token alone; instead it inventories stable handler motifs that
can be used by the AST frontend and runtime differential tests.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Dict, Iterable, Tuple
import re


@dataclass(frozen=True)
class Motif:
    name: str
    count: int
    evidence: str
    confidence: str

    def to_dict(self):
        return asdict(self)


_PATTERNS = {
    "stream_write": (r"(?:_|A|R|c|u|w|C)\s*\[[^\]]+\]\s*=", "register/instruction-stream write", "HIGH"),
    "pc_reexecute": (r"\b(?:e|pc)\s*-\s*=\s*1", "decrement-and-reexecute", "HIGH"),
    "pc_increment": (r"\b(?:e|pc)\s*\+\s*=\s*1", "explicit pc increment", "MEDIUM"),
    "table_write": (r"\[[^\]]+\]\s*=", "indexed table assignment", "LOW"),
    "call": (r"\([^\n;{}]{0,220}\)\s*\(", "call-like expression", "LOW"),
    "return": (r"\breturn\b", "return statement", "LOW"),
    "closure": (r"\bfunction\b", "nested function/closure syntax", "LOW"),
    "branch": (r"\b(?:if|elseif|else)\b", "conditional branch", "LOW"),
}


def catalog_source(src: str) -> Dict[str, Motif]:
    rows: Dict[str, Motif] = {}
    text = src or ""
    compact = re.sub(r"\s+", "", text)
    for name, (pattern, evidence, confidence) in _PATTERNS.items():
        count = len(re.findall(pattern, text))
        rows[name] = Motif(name, count, evidence, confidence if count else "NONE")
    # A stronger combined fact: an instruction-stream mutation followed by a
    # reexecute marker is the specific dynamic materializer shape we observed.
    sw = rows["stream_write"].count
    rx = rows["pc_reexecute"].count
    rows["materializer"] = Motif(
        "materializer", min(sw, rx),
        "stream mutation paired with pc reexecute",
        "HIGH" if sw and rx else "NONE",
    )
    return rows


def catalog_dict(src: str) -> Dict[str, dict]:
    return {k: v.to_dict() for k, v in catalog_source(src).items()}
