"""Static V15.1 frontend pipeline.

Stages:
    bootstrap facts -> dispatcher map -> closure graph -> normalized frontend IR
    -> shared core IR/CFG

This is intentionally separate from the dynamic V15 lifter. The dynamic bridge
can consume the same source with ``binding.bound_v151()`` when a real proto dump
is available.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List

from . import vmmap
from .bootstrap import analyze_file
from .closure import build_closure_graph
from .normalize import normalize_dispatch
from .shared_ir import lower_program
from .validate import validate_frontend, validate_shared
from .semantic_pass import audit_frontend


@dataclass
class FrontendResult:
    bootstrap: Any
    dispatchers: List[Dict[str, Any]]
    closure: Any
    programs: List[Any]
    shared: List[Any]

    def summary(self) -> Dict[str, Any]:
        validation = validate_frontend(self)
        shared_validation = validate_shared(self)
        semantic = audit_frontend(self)
        return {
            "status": "PASS" if validation["ok"] and shared_validation["ok"] else "PARTIAL",
            "validation": validation,
            "shared_validation": shared_validation,
            "dispatchers": len(self.dispatchers),
            "modes": sorted({d.get("mode") for d in self.dispatchers if d.get("mode") is not None}),
            "frontend_instructions": sum(len(p.instructions) for p in self.programs),
            "shared_nodes": sum(len(s.order) for s in self.shared),
            "unknowns": sum(len(p.unknowns()) for p in self.programs),
            "closure": self.closure.summary(),
            "semantic": semantic,
        }


def analyze(path: str, *, max_op: int = 256) -> FrontendResult:
    root = vmmap.load_ast(path)
    with open(path, "r", encoding="latin-1") as f:
        lines = f.read().split("\n")
    facts = analyze_file(path)
    dispatchers = vmmap.find_dispatchers(root)
    closure = build_closure_graph(root, dispatchers=dispatchers)
    programs = []
    shared = []
    for d in dispatchers:
        # Only the four V15.1 backend modes go through this frontend. Legacy
        # V15-shaped dispatchers remain available to the old engine.
        if d.get("mode") not in (40, 142, 217, 118):
            continue
        p = normalize_dispatch(d, lines, max_op=max_op)
        programs.append(p)
        shared.append(lower_program(p))
    return FrontendResult(facts, dispatchers, closure, programs, shared)
