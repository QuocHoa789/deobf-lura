# Termux + Discord Bot

## Install

```bash
cd ~/storage/downloads/Deobfuscator-Luraph-V15-master
chmod +x install-termux.sh start-bot.sh
./install-termux.sh
```

The installer installs Node.js/Python/build tools and `discord.js`, then checks for native `bin/luau` and `bin/luau-ast`.

The original archive contains Windows `luau.exe`/`luau-ast.exe`. Termux needs native Linux/Android binaries instead. If you already built Luau at `~/luau/build/luau`, the installer copies that `luau` binary automatically.

## Start

```bash
./start-bot.sh
```

If `DISCORD_TOKEN` is not set, the script asks for it interactively. The token is not written to a file.

Optional environment variables:

```bash
export MAX_FILE_MB=8
export DEOB_TIMEOUT_MS=3600000   # 60 min (default)
export DEOB_STACK_MB=64          # lower if the lifter gets killed on your phone
export BOT_PREFIX='!'
```

## Discord commands

- `/deobf file:<file> mode:full`
- `/deobf file:<file> mode:trace`
- `/detect file:<file>`
- `!deobf` + attach a Lua/Luau file

The bot processes one deob job at a time and rejects non-Lua/Luau/TXT attachments.

## V15.1 preflight

After installation, run:

```bash
python tools/v151-preflight.py
```

For machine-readable output:

```bash
python tools/v151-preflight.py --json
```

`native_ready: true` means both native `luau` and `luau-ast` exist and the
supplied V15.1 sample parses successfully. It does not by itself claim that the
sample was fully devirtualized.

## V15.1 Phase 16-20

Run static/runtime preflight even before native Luau is installed:

```bash
python tools/v151-preflight.py sample/v15.1/sa-obfuscated.lua.txt --json
```

If native `luau` and `luau-ast` are unavailable, the command reports a static
bootstrap/source-contract fallback and keeps dynamic status `BLOCKED`. It does
not fabricate a successful dynamic devirtualization.


See `V15.1-PHASE26-30.md` for the Phase 26-30 recovery changes.
