import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
CORE_DIR = os.path.join(HERE, "..", "core")
if CORE_DIR not in sys.path:
    sys.path.insert(0, CORE_DIR)

from backend import run_big_stack


def _profile_name(obfuscator=""):
    s = str(obfuscator or "").strip().lower().replace("-", "_")
    if "v15.1" in s or "v151" in s or "v15_1" in s:
        return "luraph_v15_1"
    if "v14" in s:
        return "luraph_v14"
    return "luraph_v15"


def _update_v151_report(config, *, dynamic_status=None, dynamic_note=None):
    report_path = config.get("v151_report")
    obfuscator = _profile_name(config.get("obfuscator"))
    if obfuscator != "luraph_v15_1" or not report_path:
        return
    try:
        from obfuscators.luraph_v15_1.report import V151Report
        from obfuscators.luraph_v15_1.runtime_probe import probe
        if os.path.exists(report_path):
            with open(report_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            report = V151Report(**{k: data[k] for k in ("profile", "sample", "phase", "static", "runtime", "dynamic", "tests", "status", "generated_at") if k in data})
        else:
            report = V151Report(sample=config.get("source_path"))
        if dynamic_status:
            report.dynamic["status"] = dynamic_status
        if dynamic_note:
            report.dynamic["note"] = dynamic_note
        if not report.runtime:
            report.runtime = probe(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), config.get("source_path")).to_dict()
        report.write(report_path)
    except Exception as exc:
        print("[!] unable to update V15.1 report: %s" % exc, file=sys.stderr)

def engine_for(obfuscator="", env=None):
    forced = (env or os.environ).get("DEOB_ENGINE")
    profile = forced if forced in ("v14", "v15", "v15_1") else _profile_name(obfuscator)
    if profile == "v14":
        from obfuscators.luraph_v14 import devirt
        return devirt
    if profile == "luraph_v15_1" or profile == "v15_1":
        from obfuscators.luraph_v15_1 import devirt
        from obfuscators.luraph_v15_1.binding import activate_v151
        activate_v151()
        return devirt
    from obfuscators.luraph_v15 import devirt
    return devirt


cmd = sys.argv[1]

if cmd == "preflight":
    source_path = sys.argv[2]
    from obfuscators.luraph_v15_1.pipeline import analyze
    from obfuscators.luraph_v15_1.runtime_probe import probe
    fr = analyze(source_path)
    rp = probe(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), source_path)
    out = {"static": fr.summary(), "runtime": rp.to_dict()}
    print(json.dumps(out, sort_keys=True))

elif cmd == "collect":
    source_path = sys.argv[2]
    protos_path = sys.argv[3]
    chunk_paths = sys.argv[4:]
    obfuscator = chunk_paths.pop() if chunk_paths and chunk_paths[-1].startswith('luraph_') else ''
    devirt = engine_for(obfuscator)
    stats, reqs, bufs = run_big_stack(
        devirt.collect_requests, source_path, protos_path, chunk_paths
    )
    result = {
        "stats": stats,
        "requests": sorted(list(reqs)),
        "bufs": bufs,
    }
    print(json.dumps(result))

elif cmd == "lift":
    source_path = sys.argv[2]
    protos_path = sys.argv[3]
    out_path = sys.argv[4]
    chunk_paths = sys.argv[5:]
    obfuscator = chunk_paths.pop() if chunk_paths and chunk_paths[-1].startswith('luraph_') else ''
    devirt = engine_for(obfuscator)
    text_out, stats, reqs, bufs = run_big_stack(
        devirt.lift_program, source_path, protos_path, chunk_paths
    )
    with open(out_path, "w", encoding="utf-8", newline="\n") as f:
        f.write(devirt.finish_text(text_out) + "\n")
    print(json.dumps({
        "stats": stats,
        "requests": sorted(list(reqs)),
        "bufs": bufs,
        "output": out_path,
    }))

elif cmd == "pipeline":

    config_file = sys.argv[2]
    with open(config_file, "r", encoding="utf-8") as f:
        c = json.load(f)

    from obfuscators.base import Job
    import harness
    profile = _profile_name(c.get('obfuscator'))
    if profile == 'luraph_v14':
        from obfuscators.luraph_v14 import driver
    elif profile == 'luraph_v15_1':
        from obfuscators.luraph_v15_1 import driver
    else:
        from obfuscators.luraph_v15 import driver

    class DummyArgs:
        def __init__(self, d):
            for k, v in d.items():
                setattr(self, k, v)

    args = DummyArgs(c["args"])
    job = Job(c["input"], c["source"], args, c["trace_path"], c["debug"], c["obfuscator"])
    job.source_path = c["source_path"]
    if c.get("v151_report"):
        setattr(args, "v151_report", c["v151_report"])
    job.credit_header = lambda: ""

    runner = harness.Runner(job)
    runner.luau = c["luau_exe"]

    try:
        driver.lift(
            job,
            runner,
            c["patched"],
            c["cfg"],
            c.get("chunks", {}),
            c["run_text"],
            c["ppath"],
            c["dpath"],
            c.get("chunk_paths", []),
        )
        if profile == "luraph_v15_1":
            _update_v151_report(c, dynamic_status=("PRODUCED" if os.path.exists(c["dpath"]) and os.path.getsize(c["dpath"]) else "NO_OUTPUT"),
                                dynamic_note="Dynamic lift returned through the existing V15 ProtoLifter under the V15.1 binding. Semantic correctness still requires sample/runtime validation.")
    finally:
        runner.finish()

    dpath = c["dpath"]
    if os.path.exists(dpath):
        with open(dpath, "r", encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
        clean = []
        skip_header = True
        for line in lines:
            stripped = line.strip()
            if skip_header and (
                stripped.startswith("-- Deobfuscated by") or
                stripped.startswith("-- Detected obfuscation") or
                stripped.startswith("-- Local names are inferred") or
                stripped.startswith("-- source:") or
                stripped.startswith("-- NOTE: reconstructed") or
                stripped.startswith("--       during the trace")
            ):
                continue
            if skip_header and stripped == "":
                continue
            skip_header = False
            clean.append(line)
        with open(dpath, "w", encoding="utf-8", newline="\n") as f:
            f.writelines(clean)

    print(json.dumps({"success": True, "output": c["dpath"]}))

else:
    sys.exit(f"Unknown command: {cmd}")
