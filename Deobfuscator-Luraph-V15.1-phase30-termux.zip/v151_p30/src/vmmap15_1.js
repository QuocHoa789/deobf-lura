'use strict';

// V15.1 runtime instrumentation adapter.
// The proven JS V15 mapper stays untouched; this adapter only removes the
// temporary local-predicate statements that prevent the legacy matcher from
// seeing a dispatcher whose semantic form is still exactly `if predicate then`.

const fs = require('fs');
const os = require('os');
const path = require('path');
const base = require('./vmmap');
const { luauAst } = require('./harness');

function loadAst(filePath) { return base.loadAst(filePath); }
function loc(node) { return base.loc(node); }
function walkAst(node, fn) { return base.walkAst(node, fn); }
function localName(expr) { return base.localName(expr); }

function isTrueWhile(n) {
  return n && n.type === 'AstStatWhile' && n.condition &&
         n.condition.type === 'AstExprConstantBool' && n.condition.value === true;
}

function indexLoad(stmt) {
  if (!stmt || !['AstStatLocal', 'AstStatAssign'].includes(stmt.type)) return null;
  if ((stmt.values || []).length !== 1 || !(stmt.vars || []).length) return null;
  const lhs = stmt.type === 'AstStatLocal' ? stmt.vars[0].name : localName(stmt.vars[0]);
  const v = stmt.values[0];
  if (!lhs || !v || v.type !== 'AstExprIndexExpr') return null;
  const arr = localName(v.expr), pc = localName(v.index);
  return arr && pc ? { lhs, arr, pc } : null;
}

function evalSimple(expr, opcodeVar, value, env) {
  if (!expr) return null;
  if (expr.type === 'AstExprConstantBool') return !!expr.value;
  if (expr.type === 'AstExprLocal') {
    if (expr.local.name === opcodeVar) return value;
    const b = env.get(expr.local.location);
    return b == null ? null : evalSimple(b, opcodeVar, value, env);
  }
  if (expr.type === 'AstExprBinary') {
    const OPS = {
      CompareLt: (a,b) => a < b, CompareLe: (a,b) => a <= b,
      CompareGt: (a,b) => a > b, CompareGe: (a,b) => a >= b,
      CompareEq: (a,b) => a === b, CompareNe: (a,b) => a !== b,
    };
    const op = OPS[expr.op];
    if (!op) return null;
    const l = evalSimple(expr.left, opcodeVar, value, env);
    const r = evalSimple(expr.right, opcodeVar, value, env);
    if (typeof l === 'number' && typeof r === 'number') return op(l, r);
  }
  return null;
}

function findDispatchers(root) {
  const found = [];
  walkAst(root, n => {
    if (!isTrueWhile(n)) return;
    const body = n.body?.body || [];
    let loadIdx = -1, load = null;
    for (let i = 0; i < Math.min(8, body.length); i++) {
      const x = indexLoad(body[i]);
      if (x) { loadIdx = i; load = x; break; }
    }
    if (!load) return;

    let treeIdx = -1;
    const predicates = [];
    const predEnv = new Map();
    for (let i = loadIdx + 1; i < Math.min(body.length, loadIdx + 12); i++) {
      const st = body[i];
      if (st.type === 'AstStatIf') { treeIdx = i; break; }
      if (st.type !== 'AstStatLocal' && st.type !== 'AstStatAssign') return;
      const vals = st.values || [], vars = st.vars || [];
      if (vals.length !== 1 || vars.length !== 1) return;
      const name = st.type === 'AstStatLocal' ? vars[0].name : localName(vars[0]);
      if (!name) return;
      predicates.push(st);
      predEnv.set(vars[0].location || vars[0].name, vals[0]);
    }
    if (treeIdx < 0) return;

    found.push({
      node: n,
      op: load.lhs,
      arr: load.arr,
      pc: load.pc,
      tree: body[treeIdx],
      rest: body.slice(treeIdx + 1),
      family: predicates.length ? 'v15.1' : 'v15',
      predicates,
    });
  });
  return found;
}

function resolveOp(tree, varName, value) {
  const env = new Map();
  function resolve(node) {
    if (!node) return null;
    if (node.type === 'AstStatBlock') {
      const body = node.body || [];
      if (body[0]?.type === 'AstStatLocal') {
        for (const v of (body[0].vars || [])) {
          const idx = (body[0].vars || []).indexOf(v);
          const val = (body[0].values || [])[idx];
          if (val) env.set(v.location || v.name, val);
        }
      }
      return body[0]?.type === 'AstStatIf' ? resolve(body[0]) : node;
    }
    if (node.type !== 'AstStatIf') return node;
    let cond = node.condition;
    let r = evalSimple(cond, varName, value, env);
    if (r == null && cond?.type === 'AstExprLocal') {
      const val = env.get(cond.local.location);
      if (val) r = evalSimple(val, varName, value, env);
    }
    if (r == null) return node;
    return r ? resolve(node.thenbody) : resolve(node.elsebody || null);
  }
  return resolve(tree);
}

function normalizeDispatchPredicates(source, root) {
  const lines = source.split('\n');
  const edits = [];

  walkAst(root, n => {
    if (!isTrueWhile(n)) return;
    const body = n.body?.body || [];
    for (let i = 1; i < Math.min(body.length, 10); i++) {
      const st = body[i];
      if (st.type === 'AstStatIf') break;
      if (st.type !== 'AstStatLocal' || (st.vars || []).length !== 1 || (st.values || []).length !== 1) continue;
      const variable = st.vars[0];
      const next = body[i + 1];
      if (!next || next.type !== 'AstStatIf' || next.condition?.type !== 'AstExprLocal') continue;
      if (next.condition.local.location !== variable.location) continue;
      // Safe only when the predicate local occurs exactly once after its
      // declaration in this dispatch-loop body: as the root if condition.
      let uses = 0;
      walkAst(body.slice(i + 1), x => {
        if (x.type === 'AstExprLocal' && x.local.location === variable.location) uses++;
      });
      if (uses !== 1) continue;
      const [l1, c1, l2, c2] = loc(st);
      const [il1, ic1, il2, ic2] = loc(next.condition);
      edits.push({ l1, c1, l2, c2, il1, ic1, il2, ic2,
        expr: lines[l1].slice(c1, c2),
      });
    }
  });

  // Apply bottom-up; replace `local p=expr;` with nothing and `if p`'s
  // condition span with the original expression text.
  edits.sort((a,b) => b.l1 - a.l1 || b.c1 - a.c1);
  for (const e of edits) {
    if (e.l1 === e.l2 && e.il1 === e.il2) {
      let line = lines[e.l1];
      const predText = e.expr.replace(/^\s*local\s+[^=]+\s*=\s*/, '').replace(/;\s*$/, '');
      line = line.slice(0, e.il1 === e.l1 ? e.ic1 : e.ic1) + predText + line.slice(e.ic2);
      // Re-locate declaration against the original line; c1/c2 are original.
      const delta = e.c2 - e.c1;
      const start = e.c1;
      const condCol = e.ic1 >= e.c2 ? e.ic1 - delta : e.ic1;
      // The simple replacement above did not remove declaration yet; do it
      // using original spans from right to left.
      line = line.slice(0, start) + line.slice(e.c2);
      if (line[start - 1] === ';' && line[start] === ';') line = line.slice(0, start) + line.slice(start + 1);
      lines[e.l1] = line;
    } else {
      // Multi-line declaration: conservative fallback—do not rewrite it.
    }
  }
  return lines.join('\n');
}

function normalizedSource(source, filePath) {
  // The normalized source is used only for the proven instrumentation matcher.
  // Never mutate the caller's source and never feed the transformed text back
  // into the V15.1 semantic resolver.
  try {
    const root = loadAst(filePath);
    return normalizeDispatchPredicates(source, root);
  } catch (e) {
    return source;
  }
}

function patchEntries(source, filePath, chunkTag) {
  // Write a transformed temporary file so the legacy instrumentation logic can
  // keep its proven closure/proto handling without changing src/vmmap.js.
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'luraph-v151-'));
  const tmp = path.join(dir, path.basename(filePath));
  try {
    fs.writeFileSync(tmp, normalizedSource(source, filePath), 'latin1');
    return base.patchEntries(fs.readFileSync(tmp, 'latin1'), tmp, chunkTag);
  } finally {
    try { fs.unlinkSync(tmp); } catch {}
    try { fs.rmdirSync(dir); } catch {}
  }
}

function patchSpin(source) { return base.patchSpin(source); }

module.exports = Object.assign({}, base, {
  loadAst, loc, walkAst, localName,
  findDispatchers,
  resolveOp,
  patchEntries,
  patchSpin,
  normalizeDispatchPredicates,
});
