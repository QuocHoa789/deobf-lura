'use strict';

function structuralRootCandidates(data) {
  const groups = new Map();
  for (const [pid, cap] of Object.entries((data && data.protos) || {})) {
    if (!cap || cap.__maker == null) continue;
    const maker = String(cap.__maker);
    const seq = Number(cap.__seq) || 0;
    let g = groups.get(maker);
    if (!g) {
      g = { maker, count: 0, firstPid: pid, firstSeq: seq };
      groups.set(maker, g);
    }
    g.count += 1;
    if (seq && (!g.firstSeq || seq < g.firstSeq)) {
      g.firstSeq = seq;
      g.firstPid = pid;
    }
  }
  return [...groups.values()]
    .sort((a, b) => (b.count - a.count) || (a.firstSeq - b.firstSeq) || a.maker.localeCompare(b.maker))
    .map(x => x.firstPid);
}

function rootCandidateRanking(data) {
  const protos = (data && data.protos) || {};
  const rootOk = Array.isArray(data && data.root_ok) ? data.root_ok : [];
  const rootProbe = new Set(Array.isArray(data && data.root_probes) ? data.root_probes.map(Number) : []);
  const generic = Array.isArray(data && data.root_candidates) ? data.root_candidates : [];
  const rootCallee = data && data.root_callee != null ? [data.root_callee] : [];
  const structural = structuralRootCandidates(data || {});
  const scores = new Map();
  const reasons = new Map();
  const order = new Map();

  const add = (x, score, reason, pos) => {
    const pid = Number(x);
    if (!Number.isFinite(pid) || !Object.prototype.hasOwnProperty.call(protos, String(pid))) return;
    scores.set(pid, (scores.get(pid) || 0) + score);
    const arr = reasons.get(pid) || [];
    arr.push(reason);
    reasons.set(pid, arr);
    order.set(pid, Math.min(order.has(pid) ? order.get(pid) : 10000, pos));
  };

  rootOk.forEach((x, i) => add(x, 300 - i * 3, 'runtime-root-ok', i));
  generic.forEach((x, i) => add(x, 140 - Math.min(i, 20) * 2, 'runtime-candidate', 50 + i));
  rootCallee.forEach((x, i) => add(x, 100 - i * 2, 'runtime-root-callee', i));
  structural.forEach((x, i) => add(x, 8 - Math.min(i, 8), 'structural-candidate', 200 + i));
  for (const x of rootProbe) {
    const pid = Number(x);
    if (!Number.isFinite(pid) || !Object.prototype.hasOwnProperty.call(protos, String(pid))) continue;
    if (scores.has(pid)) {
      scores.set(pid, scores.get(pid) - 80);
      reasons.get(pid).push('runtime-probe-penalty');
    } else {
      add(pid, -20, 'runtime-probe-only', 500);
    }
  }

  return [...scores.keys()]
    .sort((a, b) => (scores.get(b) - scores.get(a)) ||
      ((order.get(a) || 10000) - (order.get(b) || 10000)) || (a - b))
    .map(pid => ({ pid, score: scores.get(pid), reasons: reasons.get(pid) || [] }));
}

function isSuspiciousLift(text, sourceSize) {
  const lines = String(text || '').split(/\r?\n/).filter(x => x.trim() !== '');
  if (sourceSize < 100000 || lines.length > 80) return false;
  const probeObjects = (String(text || '').match(/Instance\.new\("(?:Folder|ScreenGui|Frame|Path2D|ImageButton|TextLabel)"/g) || []).length;
  const guiParents = (String(text || '').match(/\bParent\s*=\s*\w+/g) || []).length;
  return lines.length <= 16 && probeObjects >= 2 && guiParents >= 1;
}

function scoreLift(text, sourceSize) {
  const t = String(text || '');
  const lines = t.split(/\r?\n/).filter(x => x.trim() !== '').length;
  const probeObjects = (t.match(/Instance\.new\("(?:Folder|ScreenGui|Frame|Path2D|ImageButton|TextLabel)"/g) || []).length;
  const guiParents = (t.match(/\bParent\s*=\s*\w+/g) || []).length;
  const comments = (t.match(/^\s*--/gm) || []).length;
  const codeLines = Math.max(0, lines - comments);
  const weak = sourceSize >= 100000 && codeLines <= 12;
  return {
    lines,
    sourceSize,
    probeObjects,
    guiParents,
    comments,
    codeLines,
    weak,
    suspicious: isSuspiciousLift(t, sourceSize),
  };
}

function isWeakLift(text, sourceSize) {
  const q = scoreLift(text, sourceSize);
  return q.suspicious || q.weak;
}

function compareLift(aText, bText, sourceSize) {
  const a = scoreLift(aText, sourceSize);
  const b = scoreLift(bText, sourceSize);
  const aBad = (a.suspicious ? 100000 : 0) + (a.weak ? 10000 : 0);
  const bBad = (b.suspicious ? 100000 : 0) + (b.weak ? 10000 : 0);
  if (aBad !== bBad) return aBad < bBad ? 1 : -1;
  const aValue = a.codeLines + Math.min(50, a.lines) * 0.1 + Math.min(10, a.probeObjects) * -1;
  const bValue = b.codeLines + Math.min(50, b.lines) * 0.1 + Math.min(10, b.probeObjects) * -1;
  return aValue === bValue ? 0 : (aValue > bValue ? 1 : -1);
}

module.exports = {
  structuralRootCandidates,
  rootCandidateRanking,
  isSuspiciousLift,
  scoreLift,
  isWeakLift,
  compareLift,
};
