#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

echo "[1/5] Installing Termux packages..."
pkg update -y
pkg install -y nodejs python git clang cmake make unzip

echo "[2/5] Installing Discord bot dependency..."
cd "$ROOT/bot"
npm install --omit=dev
cd "$ROOT"

build_luau() {
  if [ ! -d "$HOME/luau/.git" ]; then
    echo "[+] Cloning Luau source..."
    git clone --depth 1 https://github.com/luau-lang/luau.git "$HOME/luau"
  fi
  cd "$HOME/luau"
  cmake -B build -DCMAKE_BUILD_TYPE=Release
  cmake --build build --target Luau.Repl.CLI Luau.Ast.CLI -j"${LUAU_JOBS:-2}"
}

echo "[3/5] Checking/building native Luau..."
if [ ! -x "$ROOT/bin/luau" ] || [ ! -x "$ROOT/bin/luau-ast" ]; then
  if [ -x "$HOME/luau/build/luau" ] && [ -x "$HOME/luau/build/luau-ast" ]; then
    cp "$HOME/luau/build/luau" "$ROOT/bin/luau"
    cp "$HOME/luau/build/luau-ast" "$ROOT/bin/luau-ast"
    echo "[OK] copied native Luau + AST parser from ~/luau/build"
  else
    build_luau
    cp "$HOME/luau/build/luau" "$ROOT/bin/luau"
    cp "$HOME/luau/build/luau-ast" "$ROOT/bin/luau-ast"
    echo "[OK] built and copied luau + luau-ast"
  fi
else
  echo "[OK] bin/luau and bin/luau-ast already exist"
fi

if [ ! -x "$ROOT/bin/luau" ] || [ ! -x "$ROOT/bin/luau-ast" ]; then
  echo "[!] Native Luau tools are still missing; devirt cannot run."
  exit 1
fi

echo "[4/5] Verifying native tools..."
if command -v file >/dev/null 2>&1; then
  LU_TYPE="$(file -b "$ROOT/bin/luau")"
  AST_TYPE="$(file -b "$ROOT/bin/luau-ast")"
  echo "    luau:     $LU_TYPE"
  echo "    luau-ast: $AST_TYPE"
  case "$LU_TYPE $AST_TYPE" in
    *PE32*|*MS-DOS*) echo "[!] Windows PE binary detected. Termux needs native ELF binaries."; exit 1;;
  esac
fi
"$ROOT/bin/luau" --version
"$ROOT/bin/luau-ast" --help >/dev/null

if ! "$ROOT/bin/luau-ast" "$ROOT/sample/v15.1/sa-obfuscated.lua.txt" >/dev/null 2>&1; then
  echo "[!] luau-ast cannot parse the supplied V15.1 sample; keep the native build consistent with your Luau source."
  exit 1
fi

python -m py_compile "$ROOT/core/obfuscators/luraph_v15_1/runtime_probe.py" "$ROOT/core/obfuscators/luraph_v15_1/report.py"

echo "[5/5] Permissions..."
chmod +x "$ROOT/deob.js" "$ROOT/start-bot.sh" "$ROOT/bin/luau" "$ROOT/bin/luau-ast"

echo
echo "=== INSTALL COMPLETE ==="
echo "Test v15.1 detection:"
echo "  node deob.js sample/v15.1/sa-obfuscated.lua.txt --detect"
echo "Start Discord bot: ./start-bot.sh"
echo "The bot asks for DISCORD_TOKEN when no token environment variable is set."
