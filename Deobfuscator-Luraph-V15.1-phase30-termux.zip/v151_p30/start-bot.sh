#!/data/data/com.termux/files/usr/bin/bash
set -e
cd "$(dirname "$0")"
if [ ! -d bot/node_modules/discord.js ]; then
  echo "[!] Discord dependency not installed. Run ./install-termux.sh first."
  exit 1
fi
if [ ! -x bin/luau ]; then
  echo "[!] bin/luau is missing. Run ./install-termux.sh and complete the Luau setup."
  exit 1
fi
if [ ! -x bin/luau-ast ]; then
  echo "[!] bin/luau-ast is missing. Full deob may fail until native luau-ast is installed."
fi
command -v termux-wake-lock >/dev/null 2>&1 && termux-wake-lock
export DEOB_STACK_MB="${DEOB_STACK_MB:-64}"
exec node --max-old-space-size=1024 bot/index.js
