const assert = require('assert');
const mapper = require('../src/vmmap15_1');

function local(name, location) { return {name, location}; }
function exprLocal(name, location) { return {type:'AstExprLocal', local:local(name, location)}; }
function idx(arr, pc) { return {type:'AstExprIndexExpr', expr:exprLocal(arr, 'arrloc'), index:exprLocal(pc, 'pcloc')}; }
function num(value) { return {type:'AstExprConstantNumber', value}; }

const src = 'while true do local op=_[e];local v=op<28;if v then return end;end;';
const opStmt = {
  type:'AstStatLocal', location:'0,14 - 0,27',
  vars:[local('op','oploc')], values:[idx('_','e')]
};
const predStmt = {
  type:'AstStatLocal', location:'0,28 - 0,41',
  vars:[local('v','vloc')],
  values:[{type:'AstExprBinary', location:'0,36 - 0,41', op:'CompareLt', left:exprLocal('op','oploc'), right:num(28)}]
};
const rootIf = {
  type:'AstStatIf', condition:Object.assign(exprLocal('v','vloc'), {location:'0,45 - 0,46'}), location:'0,42 - 0,62',
  thenbody:{type:'AstStatBlock', body:[{type:'AstStatReturn', location:'0,48 - 0,54'}]}
};
const root = {type:'AstStatBlock', body:[{
  type:'AstStatWhile', condition:{type:'AstExprConstantBool',value:true},
  body:{type:'AstStatBlock', body:[opStmt, predStmt, rootIf]}
}]};

const out = mapper.normalizeDispatchPredicates(src, root);
assert(out.includes('while true do local op=_[e];if op<28 then'));
assert(!out.includes('local v=op<28'));
console.log('v151 JS predicate normalizer: PASS');
