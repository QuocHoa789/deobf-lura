import json
import os
import sys
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "core"))

from obfuscators.luraph_v15_1.runtime_probe import probe, ToolProbe
from obfuscators.luraph_v15_1.report import V151Report


class TestRuntimeProbe(unittest.TestCase):
    def test_missing_tools_are_explicit(self):
        with tempfile.TemporaryDirectory() as td:
            r = probe(root=td, sample_path=None)
        self.assertFalse(r.native_ready)
        self.assertFalse(r.luau.exists)
        self.assertFalse(r.luau_ast.exists)
        self.assertEqual(r.sample_parse, "SKIP")

    def test_windows_binaries_are_not_native(self):
        from obfuscators.luraph_v15_1.runtime_probe import _native_ok
        p = ToolProbe("luau", "/tmp/luau.exe", True, True, "PE32+ executable (console) x86-64", "")
        self.assertFalse(_native_ok(p))


class TestReport(unittest.TestCase):
    def test_partial_is_not_pass(self):
        r = V151Report(static={"status": "PASS"}, dynamic={"status": "BLOCKED"})
        self.assertEqual(r.refresh_status(), "PARTIAL")

    def test_round_trip(self):
        r = V151Report(static={"status": "PASS"}, dynamic={"status": "PASS"})
        with tempfile.TemporaryDirectory() as td:
            path = os.path.join(td, "r.json")
            r.write(path)
            with open(path, encoding="utf-8") as f:
                data = json.load(f)
        self.assertEqual(data["status"], "PASS")
        self.assertEqual(data["profile"], "luraph_v15_1")


if __name__ == "__main__":
    unittest.main(verbosity=2)
