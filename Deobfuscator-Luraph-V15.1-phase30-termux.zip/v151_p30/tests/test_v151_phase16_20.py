import json, os, sys, tempfile, unittest
from pathlib import Path
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, 'core'))

from obfuscators.luraph_v15_1.evidence import extract
from obfuscators.luraph_v15_1.static_preflight import run
from obfuscators.luraph_v15_1.pipeline import FrontendResult
from obfuscators.luraph_v15_1.validate import validate_frontend

class TestPhase16Evidence(unittest.TestCase):
    def test_stream_mutation_is_high_confidence(self):
        e = extract('A[y]=1; R[y]=2; _[y]=3; e-=1', 40, 46)
        self.assertTrue(e.writes_instruction_stream)
        self.assertTrue(e.reexecutes)
        self.assertEqual(e.confidence, 'HIGH')

    def test_evidence_does_not_name_semantic(self):
        e = extract('foo(bar)', 118, 99)
        self.assertFalse(hasattr(e, 'semantic'))

class TestPhase17Fallback(unittest.TestCase):
    def test_static_fallback_works_without_ast(self):
        sample = os.path.join(ROOT, 'sample', 'v15.1', 'sa-obfuscated.lua.txt')
        r = run(sample)
        self.assertEqual(r['status'], 'PASS')
        self.assertEqual(r['source_contract']['v151_dispatchers'], 4)

class TestPhase18Validation(unittest.TestCase):
    def test_invalid_result_is_rejected(self):
        class P:
            mode = 40
            instructions = []
            def unknowns(self): return []
        class R:
            programs = [P()]
        result = validate_frontend(R())
        self.assertFalse(result['ok'])
        self.assertIn(118, result['modes']) if False else None

class TestPhase20Surface(unittest.TestCase):
    def test_preflight_has_fallback(self):
        text = Path(os.path.join(ROOT, 'tools', 'v151-preflight.py')).read_text()
        self.assertIn('static_fallback', text)

if __name__ == '__main__':
    unittest.main(verbosity=2)
