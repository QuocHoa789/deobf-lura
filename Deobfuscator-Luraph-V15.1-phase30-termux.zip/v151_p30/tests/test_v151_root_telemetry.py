from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
ENVLOG = ROOT / 'runtime' / 'envlog.luau'


class TestV151RootTelemetry(unittest.TestCase):
    def test_envlog_exports_root_ok_and_probe_buckets(self):
        text = ENVLOG.read_text(encoding='utf-8')
        self.assertIn('CHAIN.seen[c] = "ok"', text)
        self.assertIn('"root_ok"', text)
        self.assertIn('"root_probes"', text)
        self.assertIn('(CHAIN.seen or {})', text)

    def test_probe_marks_are_not_upgraded_until_root_emits_after_child(self):
        text = ENVLOG.read_text(encoding='utf-8')
        ok = text.index('CHAIN.seen[c] = "ok"')
        probe = text.index('CHAIN.seen[c] = "probe"')
        self.assertLess(ok, probe)


if __name__ == '__main__':
    unittest.main(verbosity=2)
