import hashlib, os, unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
EXPECTED = {
    '__init__.py': '542d4990ddda961abcc0bb6aa3a723b9fbfb70912aec01bdaa293dbb36ad2eaf',
    'devirt.py': 'e17dbaa1ecb868cef8bb6baed1f508b7e04d3beb87e6188fbd94dbd2640dc402',
    'driver.py': '9ac487e5fc633cd41b9b12753bc2a308d2f5f7311db461eef23355c5122aefce',
    'vmmap.py': 'd01f2d4130ac29f87101fecd03094f88aa955fe6e153e7c004560fd3fedfb596',
}
class TestV15RegressionManifest(unittest.TestCase):
    def test_v15_source_matches_phase10_manifest(self):
        base = ROOT / 'core' / 'obfuscators' / 'luraph_v15'
        diffs=[]
        for rel, expected in EXPECTED.items():
            p=base/rel
            if not p.exists():
                diffs.append(rel + ':missing'); continue
            got=hashlib.sha256(p.read_bytes()).hexdigest()
            if got != expected: diffs.append(rel)
        self.assertEqual(diffs, [], 'V15 source changed: %s' % diffs)
