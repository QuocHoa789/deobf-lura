import os
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "core"))

from obfuscators.luraph_v15_1.opcode_maps import (
    PC_CALL, PC_EXPAND, PC_NEXT, classify, get_opcode_spec
)
from obfuscators.luraph_v15_1.frontend_ir import ProgramIR, instruction_from_spec


class TestV151OpcodeMaps(unittest.TestCase):
    def test_same_opcode_is_mode_scoped(self):
        a = get_opcode_spec(40, 27)
        b = get_opcode_spec(142, 27)
        self.assertEqual(a.mode, 40)
        self.assertEqual(b.mode, 142)
        self.assertNotEqual(a.semantic, b.semantic)

    def test_unknown_is_not_guessed(self):
        spec = get_opcode_spec(40, 255)
        self.assertEqual(spec.semantic, "UNKNOWN")
        self.assertEqual(spec.confidence, "UNKNOWN")

    def test_stream_mutation_gets_expansion_effect(self):
        spec = classify(40, 6, source="A[y]=x;R[y]=z;c[y]=q;_[y]=op;e-=1")
        self.assertEqual(spec.semantic, "STREAM_EXPAND")
        self.assertEqual(spec.pc_effect, PC_EXPAND)
        self.assertTrue(spec.mutates_stream)

    def test_known_call_keeps_mode_specific_semantics(self):
        spec = get_opcode_spec(118, 70)
        self.assertEqual(spec.semantic, "PCALL")
        self.assertEqual(spec.pc_effect, PC_CALL)

    def test_ir_rejects_mixed_modes(self):
        p = ProgramIR(40)
        s = get_opcode_spec(40, 5)
        p.append(instruction_from_spec(40, 0, 5, s))
        with self.assertRaises(ValueError):
            p.append(instruction_from_spec(142, 1, 27, get_opcode_spec(142, 27)))


if __name__ == "__main__":
    unittest.main(verbosity=2)
