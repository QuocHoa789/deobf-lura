import os, sys, unittest
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, 'core'))
from obfuscators.luraph_v15_1.differential import apply_effect, replay

class TestDifferential(unittest.TestCase):
    def test_reexecute_moves_back_one(self):
        self.assertEqual(apply_effect(10, 'EXPAND_AND_REEXECUTE'), 9)

    def test_jump_uses_explicit_target(self):
        self.assertEqual(apply_effect(10, 'JUMP', target=77), 77)

    def test_return_stops(self):
        self.assertIsNone(apply_effect(10, 'RETURN'))

    def test_replay_is_bounded(self):
        rows = replay([(0, 1, 'EXPAND_AND_REEXECUTE', None)], limit=5)
        self.assertLessEqual(len(rows), 5)

if __name__ == '__main__':
    unittest.main(verbosity=2)
