import os
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "core"))

from obfuscators.luraph_v15_1.runtime_probe import probe


class TestPhase11RuntimeProbe(unittest.TestCase):
    def test_project_without_termux_tools_is_reported_not_crashed(self):
        with tempfile.TemporaryDirectory() as td:
            r = probe(td)
        self.assertFalse(r.native_ready)
        self.assertFalse(r.luau.exists)
        self.assertFalse(r.luau_ast.exists)


class TestPhase12ReportSurface(unittest.TestCase):
    def test_driver_has_report_option(self):
        src = Path(os.path.join(ROOT, "core", "obfuscators", "luraph_v15_1", "__init__.py")).read_text(encoding="utf-8")
        self.assertIn("--v151-report", src)


class TestPhase13Bridge(unittest.TestCase):
    def test_bridge_has_preflight_and_report_update(self):
        src = Path(os.path.join(ROOT, "src", "devirt_bridge.py")).read_text(encoding="utf-8")
        self.assertIn('cmd == "preflight"', src)
        self.assertIn("_update_v151_report", src)


class TestPhase14TermuxHardening(unittest.TestCase):
    def test_installer_rejects_pe(self):
        src = Path(os.path.join(ROOT, "install-termux.sh")).read_text(encoding="utf-8")
        self.assertIn("PE32", src)
        self.assertIn("luau-ast cannot parse", src)

    def test_node_adapter_defines_normalized_source(self):
        src = Path(os.path.join(ROOT, "src", "vmmap15_1.js")).read_text(encoding="utf-8")
        self.assertIn("function normalizedSource", src)


if __name__ == "__main__":
    unittest.main(verbosity=2)
