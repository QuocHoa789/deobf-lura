import os, sys, unittest
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, 'core'))

from obfuscators.luraph_v15_1.root_selection import rank_root_candidates, ranked_ids


class TestV151RootRanking(unittest.TestCase):
    def setUp(self):
        self.protos = {
            '10': {'__maker': 'vm-a', '__seq': 1},
            '20': {'__maker': 'vm-a', '__seq': 2},
            '30': {'__maker': 'vm-b', '__seq': 3},
            '40': {'__maker': 'vm-b', '__seq': 4},
        }

    def test_root_ok_beats_generic_candidate(self):
        raw = {'root_ok': [30], 'root_candidates': [20], 'root_callee': 20}
        self.assertEqual(ranked_ids(raw, self.protos)[0], 30)

    def test_root_callee_beats_structural_when_no_ok(self):
        raw = {'root_callee': 40}
        self.assertEqual(ranked_ids(raw, self.protos)[0], 40)

    def test_probe_does_not_promote_over_positive_evidence(self):
        raw = {'root_ok': [30], 'root_probes': [20], 'root_candidates': [20]}
        ids = ranked_ids(raw, self.protos)
        self.assertEqual(ids[0], 30)
        row20 = next(x for x in rank_root_candidates(raw, self.protos) if x['pid'] == 20)
        self.assertIn('runtime-probe-penalty', row20['reasons'])

    def test_unknown_ids_are_filtered(self):
        raw = {'root_ok': [999], 'root_candidates': [888], 'root_callee': 20}
        self.assertEqual(ranked_ids(raw, self.protos)[0], 20)


class TestV151RootSelectionIntegration(unittest.TestCase):
    def test_positive_root_ok_can_override_conflicting_callee(self):
        protos = {
            '20': {'__maker': 'vm-a', '__seq': 1},
            '30': {'__maker': 'vm-b', '__seq': 2},
        }
        raw = {'root_ok': [30], 'root_callee': 20, 'root_candidates': [20]}
        self.assertEqual(ranked_ids(raw, protos)[0], 30)

if __name__ == '__main__':
    unittest.main(verbosity=2)
