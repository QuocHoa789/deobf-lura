import os
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "core"))

from obfuscators.luraph_v15_1.frontend_ir import Instruction, ProgramIR
from obfuscators.luraph_v15_1.instruction_expander import (
    VMRecord, ExpansionState, expand_block, materialize_packed_instruction,
    materialize_program, split_operands,
)


class TestInstructionExpander(unittest.TestCase):
    def test_split_operands_small_width(self):
        width, high, low = split_operands(0x123)
        self.assertEqual(width, 7)
        self.assertEqual((high, low), (2, 0x23))

    def test_split_operands_medium_width(self):
        width, high, low = split_operands(0x12345)
        self.assertEqual(width, 14)
        self.assertEqual((high, low), (4, 0x2345))

    def test_materialize_is_bounded(self):
        old = VMRecord(10, 32, 7, 8, 9)
        rec, event = materialize_packed_instruction(
            pc=10, old=old, packed=0x12345, key=0x10203040,
            mode=40, masks=(21, 14, 0, 7),
        )
        self.assertEqual(rec.pc, 10)
        self.assertEqual(event.pc_after, 9)

    def test_expand_block_deterministic_and_xors_lanes(self):
        base = VMRecord(20, 46, 1, 2, 3)
        a = expand_block(base_pc=21, seed=123, count=8, base=base)
        b = expand_block(base_pc=21, seed=123, count=8, base=base)
        self.assertEqual(a, b)
        self.assertEqual(len(a), 8)
        self.assertTrue(all(0 <= x.opcode <= 127 for x in a))
        lanes = []
        raw_base = expand_block(base_pc=21, seed=123, count=1, base=VMRecord(20,0,0,0,0))[0]
        self.assertIsInstance(raw_base, VMRecord)

    def test_expand_block_uses_existing_destination(self):
        base = VMRecord(20, 46, 1, 2, 3)
        old = VMRecord(21, 100, 10, 20, 30)
        got = expand_block(base_pc=21, seed=123, count=1, base=base, existing=lambda _pc: old)[0]
        zero = expand_block(base_pc=21, seed=123, count=1, base=VMRecord(20, 0, 0, 0, 0))[0]
        self.assertEqual(got.opcode, old.opcode ^ zero.opcode)
        self.assertEqual(got.a, old.a ^ zero.a)
        self.assertEqual(got.r, old.r ^ zero.r)
        self.assertEqual(got.c, old.c ^ zero.c)

    def test_program_materialize(self):
        p = ProgramIR(40)
        p.append(Instruction(40, 1, 6, "STREAM_EXPAND", pc_effect="EXPAND_AND_REEXECUTE", mutates_stream=True))
        p.append(Instruction(40, 2, 4, "MOVE"))

        def resolver(ins):
            return [VMRecord(ins.pc, 44, 1, 2, 3)]

        out, state = materialize_program(p, resolver)
        self.assertEqual(len(out.instructions), 2)
        self.assertEqual(state.generated, 1)
        self.assertTrue(state.events)

    def test_cycle_limit(self):
        state = ExpansionState(max_steps=2)
        state.visit(1)
        state.visit(2)
        with self.assertRaises(RuntimeError):
            state.visit(3)


if __name__ == "__main__":
    unittest.main(verbosity=2)
