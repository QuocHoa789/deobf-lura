"""Tests of the successor-recovery / CFG-closure logic of Program._walk
(core/obfuscators/luraph_v15/devirt.py) on synthetic state graphs.

    python3 tests/test_devirt_recovery.py          (or: python3 -m unittest discover tests)

The walker only needs a stepper (state -> IR node), a lifter (bookkeeping
attributes) and State/Node/Next, so a tiny fake VM exercises the real _walk,
propagate and structure.build_cfg code.
"""
import os
import sys
import types
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "core"))
sys.path.insert(0, os.path.join(ROOT, "core", "obfuscators", "luraph_v15"))

import devirt as D          # noqa: E402
import structure as ST      # noqa: E402
from luasym import Reg, Const  # noqa: E402


def S_(pc, jregs=(), mode=0):
    return D.State(mode, pc, None, jregs)


class FakeStepper:
    """graph: pc -> list of successor States (or callables state -> list).
    0 successors = return, 1 = goto, 2+ = branch on an unknown register."""

    def __init__(self, graph, node_cls=None):
        self.graph = graph
        self.new_carry = False
        self.carry = set()
        self.steps = 0
        self.node_cls = node_cls or D.Node

    def initial(self):
        return S_(0)

    def step(self, state, prefix):
        self.steps += 1
        succ = self.graph(state) if callable(self.graph) else self.graph.get(state.pc, [])
        N = self.node_cls
        if not succ:
            return N([], outcome=D.Ret(None))
        if len(succ) == 1:
            return N([], outcome=D.Next(succ[0]))
        node = N([], cond=Reg(1000 + self.steps))     # a fresh unknown register: both edges feasible
        node.then = N([], outcome=D.Next(succ[0]))
        node.els = N([], outcome=D.Next(succ[1]))
        if len(succ) > 2:
            raise AssertionError("fake stepper supports at most two successors")
        return node


def fake_lifter():
    dump = types.SimpleNamespace(buf_patch=D.PatchLog(), tab_patch=D.PatchLog(), misses={})
    return types.SimpleNamespace(walk_only=False, stack_base=None, jump_regs=set(), pack_killed=set(),
                                 pack_unstable=set(), last_op=None, captured_regs=set(), dump=dump,
                                 requests=set(), children=[], frame_uses=set(), reg_arrays=set())


def walk(graph, limit=250000, node_cls=None, walk_only=False):
    prog = D.Program.__new__(D.Program)
    vm = types.SimpleNamespace(kstack_link=None)
    lf = fake_lifter()
    lf.walk_only = walk_only
    st = FakeStepper(graph, node_cls)
    s0, order, restart = prog._walk(vm, lf, st, limit)
    walk.lf = lf
    return prog, vm, st, s0, order, restart


def pcs(order):
    return sorted(k[1] for k, _ in order)


def cfg_errors(order, vm):
    _, blocks = ST.build_cfg(order[0][0], order, D, vm.kstack_link)
    return [b.error for b in blocks.values() if b.kind == "error"]


class Patched:
    """Temporarily override devirt's module-level ceilings."""

    def __init__(self, **kw):
        self.kw, self.old = kw, {}

    def __enter__(self):
        for k, v in self.kw.items():
            self.old[k] = getattr(D, k)
            setattr(D, k, v)

    def __exit__(self, *a):
        for k, v in self.old.items():
            setattr(D, k, v)


class TestRecovery(unittest.TestCase):

    def test_A_normal_cfg_needs_no_recovery(self):
        g = {0: [S_(1)], 1: [S_(2)], 2: []}
        _, vm, st, _, order, restart = walk(g)
        self.assertFalse(restart)
        self.assertEqual(pcs(order), [0, 1, 2])
        self.assertEqual(st.steps, 3)
        self.assertTrue(order.info["closed"])
        self.assertEqual(order.info["rounds"], 0)
        self.assertIsNone(order.info["first_stop"])
        self.assertEqual(order.info["recovered"], 0)
        self.assertEqual(cfg_errors(order, vm), [])

    def test_B_budget_stop_resumes_frontier_instead_of_dropping_it(self):
        # A -> B -> C, B -> D : with a 2-state budget the legacy walk stopped with
        # C/D never stepped and still reported "complete".
        g = {0: [S_(1)], 1: [S_(2), S_(3)], 2: [], 3: []}
        _, vm, st, _, order, restart = walk(g, limit=2)
        self.assertFalse(restart)
        self.assertEqual(pcs(order), [0, 1, 2, 3])
        self.assertTrue(order.info["closed"])
        self.assertEqual(order.info["first_stop"], "limit")
        self.assertGreaterEqual(order.info["rounds"], 1)
        self.assertEqual(cfg_errors(order, vm), [])
        # every state was stepped exactly once (nothing re-stepped by the resume)
        self.assertEqual(st.steps, 4)

    def test_C_recursive_recovery_to_fixed_point(self):
        g = {i: [S_(i + 1)] for i in range(0, 6)}
        g[6] = []
        _, vm, st, _, order, _ = walk(g, limit=1)
        self.assertEqual(pcs(order), list(range(7)))
        self.assertTrue(order.info["closed"])
        self.assertEqual(cfg_errors(order, vm), [])

    def test_plateau_stop_keeps_frontier_and_recovers_novel_pcs_first(self):
        # The real-world failure: a loop whose state key keeps changing (here a
        # counter in the jump registers) churns past the plateau cut-off while
        # successors at never-seen pcs wait in the frontier.
        N = 30000

        def g(state):
            if state.pc == 0:
                return [S_(5, ((8, 0),)), S_(100)]      # DFS (LIFO) takes the loop first
            if state.pc == 5:
                n = state.jregs[0][1]
                return [S_(5, ((8, n + 1),))] if n < N else [S_(6)]
            if state.pc in (100, 101):
                return [S_(state.pc + 1)]
            return []
        _, vm, st, _, order, restart = walk(g)
        self.assertFalse(restart)
        info = order.info
        self.assertEqual(info["first_stop"], "plateau")
        self.assertTrue(info["closed"], info)
        self.assertEqual(info["pending"], 0)
        self.assertEqual({100, 101, 102} <= set(pcs(order)), True)
        self.assertIn(6, pcs(order))
        self.assertEqual(cfg_errors(order, vm), [])
        # the node stepped at the moment of the plateau cut-off was still propagated
        self.assertEqual(len([1 for _, n in order if n.outcome is None and n.cond is None]), 0)

    def test_closure_pass_recovers_successor_missing_from_frontier(self):
        # A Next successor that never reached the work queue (propagate saw the branch
        # as decided, the CFG builder sees it undecided): the closure pass finds it,
        # rebuilds the exact state from the predecessor and steps it.
        class ForgetfulNode(D.Node):
            decided = None

            def __setattr__(self, k, v):
                if k != "decided":
                    object.__setattr__(self, k, v)

        class DecidedStepper(FakeStepper):
            def step(self, state, prefix):
                node = super().step(state, prefix)
                if node.cond is not None:
                    node.cond = Reg(1)
                    node.stmts = [D.Assign(Reg(1), Const(True))]     # fact: r1 == true => then-branch only
                return node
        prog = D.Program.__new__(D.Program)
        vm = types.SimpleNamespace(kstack_link=None)
        lf = fake_lifter()
        st = DecidedStepper({0: [S_(1), S_(2)], 1: [], 2: []}, ForgetfulNode)
        _, order, restart = prog._walk(vm, lf, st, 250000)
        self.assertEqual(pcs(order), [0, 1, 2])
        self.assertTrue(order.info["closed"])
        self.assertGreaterEqual(order.info["rounds"], 1)
        self.assertEqual(order.info["no_facts"] + 0, order.info["no_facts"])   # exact state used either way
        self.assertEqual(cfg_errors(order, vm), [])

    def test_E_unbounded_state_space_terminates_with_diagnostics(self):
        # Every state spawns two fresh ones: the frontier grows forever.
        def g(state):
            if state.pc == 0:
                return [S_(1, ((8, 0),)), S_(50)]
            if state.pc == 1:
                n = state.jregs[0][1]
                return [S_(1, ((8, 2 * n + 1),)), S_(1, ((8, 2 * n + 2),))]
            return []
        with Patched(WALK_LIMIT=500, WALK_MAX_STATES=4000, WALK_RECOVERY_LIMIT=2000, WALK_RECOVERY_STALL=300):
            _, vm, st, _, order, restart = walk(g, limit=500)
        info = order.info
        self.assertFalse(restart)
        self.assertFalse(info["closed"])
        self.assertIn(info["final_stop"], ("diverging", "recovery-limit", "limit"))
        self.assertGreater(info["pending"], 0)
        self.assertTrue(info["missing"])
        # recovery made no progress => it was rolled back: the kept walk is exactly the
        # pre-recovery one (same size as the first budget), nothing recovered stays
        rb = info["rolled_back"]
        self.assertGreater(rb["states"], 0)
        self.assertGreaterEqual(rb["missing_after"], rb["missing_before"])
        self.assertEqual(len(order), 500)
        errs = cfg_errors(order, vm)
        self.assertTrue(errs)
        for e in errs:
            self.assertTrue(e.startswith("unexplored successor "), e)
            self.assertIn("walk stop:", e)
            self.assertIn("pending:", e)

    def test_invalid_successor_is_reported_not_swallowed(self):
        # A successor whose pc is symbolic cannot be stepped: the safety check
        # (error block) stays, nothing is turned into a fake `end`.
        g = {0: [S_(1)], 1: [S_("sym")]}
        _, vm, st, _, order, restart = walk(g, limit=250000)
        self.assertTrue(any(getattr(n, "error", None) for _, n in order))
        errs = cfg_errors(order, vm)
        self.assertTrue(errs and all(e for e in errs))

    def test_walk_only_does_not_enter_recovery(self):
        g = {0: [S_(1)], 1: [S_(2), S_(3)], 2: [], 3: []}
        _, vm, st, _, order, _ = walk(g, limit=2, walk_only=True)
        self.assertEqual(order.info["rounds"], 0)
        self.assertFalse(order.info["closed"])

    def test_dedup_key_still_includes_vm_context(self):
        # same pc, different jump registers => different states (never merged by pc alone)
        g = {0: [S_(1, ((8, 1),)), S_(1, ((8, 2),))], 1: []}
        _, vm, st, _, order, _ = walk(g)
        self.assertEqual(pcs(order), [0, 1, 1])


if __name__ == "__main__":
    unittest.main(verbosity=2)
