import os
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "core"))

from obfuscators.luraph_v15_1.closure import build_closure_graph
from obfuscators.luraph_v15_1.frontend_ir import Instruction, ProgramIR
from obfuscators.luraph_v15_1.opcode_maps import get_opcode_spec
from obfuscators.luraph_v15_1.shared_ir import SharedState, lower_program
import structure
import ir


def loc(i):
    return "%d,0 - %d,1" % (i, i)


def local_decl(name, line):
    return {"name": name, "location": "%s@%d" % (name, line)}


def expr_local(name, line):
    return {"type": "AstExprLocal", "local": local_decl(name, line)}


def fn(line, args, body):
    return {"type": "AstExprFunction", "location": loc(line),
            "args": [local_decl(x, line) for x in args],
            "vararg": False,
            "body": {"type": "AstStatBlock", "body": body, "location": loc(line)}}


def idx(base, key, line):
    return {"type": "AstExprIndexExpr", "expr": expr_local(base, line), "index": expr_local(key, line)}


class TestClosureGraph(unittest.TestCase):
    def test_capture_and_proto_candidates_are_graph_based(self):
        inner = fn(20, ["x"], [
            {"type": "AstStatReturn", "list": [expr_local("proto", 10)], "location": loc(21)},
        ])
        maker = fn(10, ["seed", "proto", "ups"], [
            {"type": "AstStatLocal", "vars": [local_decl("inner", 19)], "values": [inner], "location": loc(19)},
            {"type": "AstStatReturn", "list": [expr_local("inner", 19)], "location": loc(30)},
        ])
        outer = {"type": "AstStatLocal", "vars": [local_decl("proto", 10)],
                 "values": [{"type": "AstExprConstantNumber", "value": 1}], "location": loc(1)}
        root = {"type": "AstStatBlock", "body": [outer, maker], "location": loc(1)}
        g = build_closure_graph(root)
        self.assertGreaterEqual(g.summary()["functions"], 2)
        inner_id = next(k for k in g.functions if g.functions[k].location == loc(20))
        self.assertTrue(g.functions[inner_id].captures)
        maker_id = next(k for k in g.functions if g.functions[k].location == loc(10))
        # Ambiguity is tolerated; the graph must expose candidates rather than
        # assuming parameter #2 solely by convention.
        self.assertTrue(g.functions[maker_id].proto_candidates)


class TestSharedIR(unittest.TestCase):
    def test_lowering_produces_core_ir_nodes(self):
        p = ProgramIR(40)
        p.append(Instruction(40, 0, 5, "ADD", a=1, b=2, c=3))
        p.append(Instruction(40, 1, 43, "JUMP", a=3, pc_effect="JUMP"))
        p.append(Instruction(40, 3, 0, "UNKNOWN", a=0, terminator=True, pc_effect="RETURN"))
        shared = lower_program(p)
        self.assertEqual(len(shared.order), 3)
        self.assertEqual(shared.order[0][0][0:2], (40, 0))
        self.assertTrue(hasattr(shared.order[0][1], "outcome"))
        entry, blocks = structure.build_cfg(shared.order[0][0], shared.order, ir, "v151")
        self.assertIn(entry, blocks)
        self.assertGreaterEqual(len(blocks), 2)

    def test_shared_state_key_is_stable(self):
        self.assertEqual(SharedState(118, 7).key(None)[:2], (118, 7))


if __name__ == "__main__":
    unittest.main(verbosity=2)
