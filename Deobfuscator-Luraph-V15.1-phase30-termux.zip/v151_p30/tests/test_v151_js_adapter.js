'use strict';
const path = require('path');
const mapper = require(path.join(__dirname, '..', 'src', 'vmmap15_1'));
if (typeof mapper.normalizeDispatchPredicates !== 'function') throw new Error('normalizer export missing');
if (typeof mapper.patchEntries !== 'function') throw new Error('patchEntries export missing');
console.log('v151 JS adapter exports: PASS');
