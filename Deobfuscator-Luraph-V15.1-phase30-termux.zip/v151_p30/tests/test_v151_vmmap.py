import os
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "core"))

from obfuscators.luraph_v15_1 import vmmap


def loc(i):
    return "%d,0 - %d,1" % (i, i)


def local_expr(name, location=None):
    return {"type": "AstExprLocal", "local": {"name": name, "location": location or name + "@0"}}


def num(v):
    return {"type": "AstExprConstantNumber", "value": v}


def cmp_(op, left, right):
    return {"type": "AstExprBinary", "op": op, "left": left, "right": right}


def idx(arr, pc):
    return {"type": "AstExprIndexExpr", "expr": local_expr(arr), "index": local_expr(pc)}


def local(name, value, line):
    return {"type": "AstStatLocal", "vars": [{"name": name, "location": name + "@" + str(line)}],
            "values": [value], "location": loc(line)}


def block(*body):
    return {"type": "AstStatBlock", "body": list(body), "location": loc(1)}


def if_(cond, thenbody, elsebody=None, line=1):
    d = {"type": "AstStatIf", "condition": cond, "thenbody": thenbody, "location": loc(line)}
    if elsebody is not None:
        d["elsebody"] = elsebody
    return d


def while_(body, line=1):
    return {"type": "AstStatWhile", "condition": {"type": "AstExprConstantBool", "value": True},
            "body": block(*body), "location": loc(line)}


class TestV151VmMap(unittest.TestCase):
    def test_nested_predicate_dispatcher_resolves(self):
        op_load = local("l", idx("_", "e"), 2)
        p1 = local("v", cmp_("CompareLt", local_expr("l"), num(28)), 3)
        p2 = local("v", cmp_("CompareLt", local_expr("l"), num(14)), 4)
        h0 = block({"type": "AstStatReturn", "location": loc(10)})
        h1 = block({"type": "AstStatBreak", "location": loc(11)})
        tree = if_(local_expr("v"), block(p2, if_(local_expr("v"), h0, h1, 5)), h1, 4)
        w = while_([op_load, p1, tree], 2)
        root = block(w)
        ds = vmmap.find_dispatchers(root)
        self.assertEqual(len(ds), 1)
        self.assertEqual(ds[0]["family"], "v15.1")
        self.assertEqual(ds[0]["arr"], "_")
        self.assertEqual(ds[0]["pc"], "e")
        self.assertIsNotNone(vmmap.resolve(ds[0]["tree"], "l", 4))
        h20 = vmmap.resolve(ds[0]["tree"], "l", 20)
        self.assertIsNotNone(h20)
        self.assertEqual(h20["body"][0]["type"], "AstStatBreak")

    def test_mode_guard_is_carried(self):
        mode_pred = local("M", cmp_("CompareEq", local_expr("F"), num(40)), 1)
        w = while_([local("l", idx("_", "e"), 2),
                    local("v", cmp_("CompareLt", local_expr("l"), num(2)), 3),
                    if_(local_expr("v"), block({"type": "AstStatBreak", "location": loc(4)}),
                        block({"type": "AstStatReturn", "location": loc(5)}), 4)], 2)
        root = block(mode_pred, if_(local_expr("M"), block(w), None, 1))
        ds = vmmap.find_dispatchers(root)
        self.assertEqual(len(ds), 1)
        self.assertEqual(ds[0]["mode"], 40)

    def test_direct_v15_shape_still_works(self):
        op_load = local("op", idx("A", "i"), 2)
        tree = if_(cmp_("CompareLt", local_expr("op"), num(3)),
                   block({"type": "AstStatReturn", "location": loc(7)}),
                   block({"type": "AstStatBreak", "location": loc(8)}), 3)
        w = while_([op_load, tree], 2)
        root = block(w)
        ds = vmmap.find_dispatchers(root)
        self.assertEqual(len(ds), 1)
        self.assertEqual(ds[0]["family"], "v15")
        self.assertIsNotNone(vmmap.resolve(ds[0]["tree"], "op", 2))
        self.assertIsNotNone(vmmap.resolve(ds[0]["tree"], "op", 9))


if __name__ == "__main__":
    unittest.main(verbosity=2)
