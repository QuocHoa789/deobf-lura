import os
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "core"))

from obfuscators.luraph_v15_1.stream_decoder import (
    BitOps, MASK29, StreamState, band, bxor, decode_compact_stream,
    decode_compact_word, decode_mixed_bytes, observed_mix_step,
    transform_aligned_region,
)


class TestCompactWord(unittest.TestCase):
    def test_one_byte(self):
        r = decode_compact_word(bytes([127]))
        self.assertEqual((r.value, r.next_pos), (127, 1))

    def test_two_byte(self):
        r = decode_compact_word(bytes([128, 7]))
        self.assertEqual(r.value, 7)
        self.assertEqual(r.next_pos, 2)

    def test_three_byte(self):
        r = decode_compact_word(bytes([128, 128, 5]))
        self.assertEqual(r.value, 640)
        self.assertEqual(r.next_pos, 3)

    def test_four_byte(self):
        r = decode_compact_word(bytes([128, 128, 128, 9]))
        self.assertEqual(r.value, 9)
        self.assertEqual(r.next_pos, 4)

    def test_truncation_is_explicit(self):
        with self.assertRaises(ValueError):
            decode_compact_word(bytes([255, 255, 255]))

    def test_stream(self):
        values, pos = decode_compact_stream(bytes([1, 128, 7, 127]))
        self.assertEqual(values, [1, 7, 127])
        self.assertEqual(pos, 4)


class TestStatefulMix(unittest.TestCase):
    def test_mix_is_29_bit_bounded(self):
        x = observed_mix_step(0x12345678)
        self.assertLess(x, 1 << 29)
        self.assertGreaterEqual(x, 0)

    def test_mix_deterministic(self):
        self.assertEqual(
            decode_mixed_bytes(0x1020304, 32),
            decode_mixed_bytes(0x1020304, 32),
        )

    def test_mix_uses_four_seven_bit_lanes(self):
        raw = decode_mixed_bytes(12345, 64)
        self.assertTrue(all(0 <= b <= 127 for b in raw))

    def test_transform_aligned_and_tail(self):
        data = bytearray(range(9))
        before = bytes(data)
        transform_aligned_region(data, 0, len(data), 0x01020304)
        self.assertNotEqual(bytes(data[:4]), before[:4])
        self.assertEqual(len(data), 9)

    def test_state_read(self):
        st = StreamState(bytes([128, 7, 3]))
        self.assertEqual(st.read_compact(), 7)
        self.assertEqual(st.read_compact(), 3)
        self.assertEqual(st.remaining(), 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
