import os
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, 'core'))

from obfuscators.luraph_v15_1.binding import _v151_vm_roots
from obfuscators.luraph_v15 import devirt as base_devirt


class DummyDump:
    def __init__(self, protos, raw):
        self.protos = protos
        self.raw = raw


class DummyProg:
    def __init__(self, protos, raw):
        self.dump = DummyDump(protos, raw)


class TestV151RootSelection(unittest.TestCase):
    def test_runtime_candidate_selects_matching_proto_and_vm(self):
        p = DummyProg(
            {
                '10': {'__maker': 'vm-a', '__seq': 1},
                '20': {'__maker': 'vm-a', '__seq': 2},
                '30': {'__maker': 'vm-b', '__seq': 3},
            },
            {'root_candidates': [20, 99], 'root_callee': 10},
        )
        vms, payload = _v151_vm_roots(p)
        self.assertEqual(payload, 'vm-a')
        payload_group = next(group for group in vms if group[0] == 'vm-a')
        self.assertEqual(payload_group[1][0][1], '20')


    def test_root_ok_is_preferred_over_generic_candidates(self):
        p = DummyProg(
            {
                '10': {'__maker': 'vm-a', '__seq': 1},
                '20': {'__maker': 'vm-a', '__seq': 2},
                '30': {'__maker': 'vm-b', '__seq': 3},
            },
            {'root_ok': [30], 'root_candidates': [20], 'root_callee': 20},
        )
        vms, payload = _v151_vm_roots(p)
        self.assertEqual(payload, 'vm-b')
        payload_group = next(group for group in vms if group[0] == 'vm-b')
        self.assertEqual(payload_group[1][0][1], '30')

    def test_missing_candidates_fall_back_to_original_engine(self):
        p = DummyProg(
            {
                '10': {'__maker': 'vm-a', '__seq': 1},
                '20': {'__maker': 'vm-b', '__seq': 2},
            },
            {'root_callee': 20},
        )
        expected = base_devirt._vm_roots(p)
        got = _v151_vm_roots(p)
        self.assertEqual(got[1], expected[1])
        self.assertEqual(got[0][0][0], expected[0][0][0])

    def test_unknown_candidate_does_not_override_fallback(self):
        p = DummyProg(
            {
                '10': {'__maker': 'vm-a', '__seq': 1},
                '20': {'__maker': 'vm-b', '__seq': 2},
            },
            {'root_candidates': [999], 'root_callee': 20},
        )
        expected = base_devirt._vm_roots(p)
        got = _v151_vm_roots(p)
        self.assertEqual(got[1], expected[1])
        self.assertEqual(got[0][0][0], expected[0][0][0])


if __name__ == '__main__':
    unittest.main(verbosity=2)
