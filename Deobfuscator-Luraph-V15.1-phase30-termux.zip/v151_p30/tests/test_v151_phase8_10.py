import os
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "core"))
sys.path.insert(0, os.path.join(ROOT, "src"))

from obfuscators.luraph_v15 import devirt as base_devirt
from obfuscators.luraph_v15 import vmmap as base_vmmap
from obfuscators.luraph_v15_1 import vmmap as v151_vmmap
from obfuscators.luraph_v15_1.binding import bound_v151
from obfuscators.luraph_v15_1.bootstrap import analyze_file, sample_text_contract
from obfuscators.luraph_v15_1.frontend_ir import Instruction, ProgramIR
from obfuscators.luraph_v15_1.shared_ir import lower_program


class TestPhase8Binding(unittest.TestCase):
    def test_binding_is_scoped_and_restores_v15(self):
        self.assertIs(base_devirt.vmmap, base_vmmap)
        old_cache = getattr(base_devirt, "_SOURCE_CACHE", None)
        with bound_v151() as bound:
            self.assertIs(bound.vmmap, v151_vmmap)
            self.assertIsNot(bound._SOURCE_CACHE, old_cache)
        self.assertIs(base_devirt.vmmap, base_vmmap)
        self.assertIs(getattr(base_devirt, "_SOURCE_CACHE", None), old_cache)


class TestPhase9Bootstrap(unittest.TestCase):
    def test_supplied_sample_bootstrap_contract(self):
        sample = os.path.join(ROOT, "sample", "v15.1", "sa-obfuscated.lua.txt")
        facts = analyze_file(sample)
        self.assertEqual(facts.modes, (40, 142, 217, 118))
        self.assertTrue(facts.has_buffer_fromstring)
        self.assertTrue(facts.has_bit32_mix)
        self.assertGreaterEqual(facts.reexecute_hits, 4)
        self.assertIn(536870911, facts.rolling_constants)
        self.assertIn("pV", facts.decoder_functions)
        with open(sample, "r", encoding="latin-1") as f:
            contract = sample_text_contract(f.read())
        self.assertEqual(contract["legacy_dispatchers"], 4)
        self.assertEqual(contract["v151_dispatchers"], 4)
        self.assertEqual(contract["dispatcher_shapes"], 8)
        self.assertEqual(contract["backend_modes"], 4)


class TestPhase10NoRegression(unittest.TestCase):
    def test_v151_bridge_routes_profile_binding(self):
        bridge_path = os.path.join(ROOT, "src", "devirt_bridge.py")
        with open(bridge_path, "r", encoding="utf-8") as f:
            src = f.read()
        self.assertIn("activate_v151()", src)
        self.assertIn("profile == \"luraph_v15_1\"", src)

    def test_v15_shared_ir_shape_stays_independent(self):
        p = ProgramIR(40)
        p.append(Instruction(40, 0, 5, "ADD", a=1, b=2, c=3))
        shared = lower_program(p)
        self.assertEqual(shared.order[0][0][0:2], (40, 0))
        self.assertTrue(hasattr(base_devirt, "ProtoLifter"))
        self.assertTrue(hasattr(base_vmmap, "find_dispatchers"))


if __name__ == "__main__":
    unittest.main(verbosity=2)
