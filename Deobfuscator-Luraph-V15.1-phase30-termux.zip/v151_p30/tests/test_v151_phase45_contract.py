import os
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SAMPLE = os.path.join(ROOT, "sample", "v15.1", "sa-obfuscated.lua.txt")


class TestV151Phase45Contract(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with open(SAMPLE, "r", encoding="latin-1") as f:
            cls.src = f.read()

    def test_all_four_backend_guards_are_present(self):
        for mode in (40, 142, 217, 118):
            self.assertIn("F==%d" % mode, self.src)

    def test_compact_reader_formula_is_present(self):
        self.assertIn("(A2-128)*128+C2", self.src)
        self.assertIn("(A2-128)*16384+(C2-128)+u2*128", self.src)
        self.assertIn("(A2-128)*2097152+(C2-128)*128+(u2-128)*16384", self.src)

    def test_rolling_mix_shape_is_present(self):
        self.assertIn("z(j,13)", self.src)
        self.assertIn("h(j,13)", self.src)
        self.assertIn("z(j,14)", self.src)
        self.assertIn("536870911", self.src)

    def test_reexecute_materializers_are_present(self):
        self.assertGreaterEqual(self.src.count("e-=1;"), 4)
        self.assertIn("_[e]=44", self.src)
        self.assertIn("_[e]=45", self.src)
        self.assertIn("_[e]=68", self.src)

    def test_mode_specific_packed_masks_are_present(self):
        for marker in ("A2(y,116", "A2(X,68", "A2(p,79", "A2(d,26",
                       "A2(p,40", "A2(K,71", "A2(X,91", "A2(y,94",
                       "A2(j,56", "A2(d,11", "A2(p,36", "A2(X,74",
                       "A2(p,55", "A2(X,44", "A2(d,119", "A2(y,12"):
            self.assertIn(marker, self.src)


if __name__ == "__main__":
    unittest.main(verbosity=2)
