import os, sys, unittest
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, 'core'))

from obfuscators.luraph_v15_1.controlflow import analyze, expected_effect
from obfuscators.luraph_v15_1.handler_catalog import catalog_source
from obfuscators.luraph_v15_1.semantic_pass import audit_program
from obfuscators.luraph_v15_1.quality_gate import evaluate_source
from obfuscators.luraph_v15_1.frontend_ir import ProgramIR, Instruction


class TestPhase21Motifs(unittest.TestCase):
    def test_materializer_pair(self):
        c = catalog_source('A[y]=1;R[y]=2;_[y]=3;e-=1')
        self.assertGreaterEqual(c['materializer'].count, 1)

    def test_pc_reexecute(self):
        f = analyze('A[y]=1;e-=1')
        self.assertTrue(f.reexecute)
        self.assertEqual(expected_effect('A[y]=1;e-=1', 'NEXT'), 'EXPAND_AND_REEXECUTE')


class TestPhase23Semantic(unittest.TestCase):
    def test_unknown_is_preserved(self):
        p = ProgramIR(40)
        p.append(Instruction(40, 1, 255, 'UNKNOWN'))
        r = audit_program(p)
        self.assertEqual(r['unknown'], 1)
        self.assertEqual(r['known'], 0)


class TestPhase25Gate(unittest.TestCase):
    def test_sample_gate(self):
        path = os.path.join(ROOT, 'sample', 'v15.1', 'sa-obfuscated.lua.txt')
        r = evaluate_source(path)
        self.assertEqual(r['status'], 'PASS')
        self.assertTrue(r['checks']['all_modes'])
        self.assertTrue(r['checks']['materializer'])

if __name__ == '__main__':
    unittest.main(verbosity=2)
