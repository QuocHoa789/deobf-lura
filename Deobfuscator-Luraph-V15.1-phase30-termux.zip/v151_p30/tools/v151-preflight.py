#!/usr/bin/env python3
"""One-command V15.1 static/runtime preflight for Termux or desktop Python."""
import argparse
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CORE = os.path.join(ROOT, "core")
if CORE not in sys.path:
    sys.path.insert(0, CORE)

from obfuscators.luraph_v15_1.bootstrap import analyze_file
from obfuscators.luraph_v15_1.pipeline import analyze
from obfuscators.luraph_v15_1.static_preflight import run as static_fallback
from obfuscators.luraph_v15_1.runtime_probe import probe
from obfuscators.luraph_v15_1.quality_gate import evaluate_source


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("sample", nargs="?", default=os.path.join(ROOT, "sample", "v15.1", "sa-obfuscated.lua.txt"))
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()
    facts = analyze_file(args.sample)
    static = {"bootstrap": facts.to_dict(), "source_contract": {}, "quality_gate": evaluate_source(args.sample)}
    try:
        static["pipeline"] = analyze(args.sample).summary()
    except Exception as exc:
        static["pipeline_error"] = str(exc)
        static["fallback"] = static_fallback(args.sample)
    runtime = probe(ROOT, args.sample).to_dict()
    result = {
        "profile": "luraph_v15_1",
        "sample": os.path.abspath(args.sample),
        "static": static,
        "runtime": runtime,
        "dynamic_status": "READY_FOR_RUNTIME_LIFT" if runtime["native_ready"] else "BLOCKED",
    }
    if args.json:
        print(json.dumps(result, indent=2, sort_keys=True))
    else:
        print("[V15.1] sample:", result["sample"])
        print("[V15.1] modes:", facts.modes)
        print("[V15.1] decoder:", ", ".join(facts.decoder_functions) or "none")
        print("[V15.1] native_ready:", runtime["native_ready"])
        print("[V15.1] sample_parse:", runtime["sample_parse"])
        if runtime["native_ready"]:
            print("[V15.1] dynamic_status: READY_FOR_RUNTIME_LIFT")
        else:
            print("[V15.1] dynamic_status: BLOCKED (native luau + luau-ast required)")
    return 0 if runtime["native_ready"] else 2

if __name__ == "__main__":
    raise SystemExit(main())
